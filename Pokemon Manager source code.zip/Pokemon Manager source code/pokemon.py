import random
from datetime import datetime
import logging as log

class Pokemon():
    def __init__(self, species, data, abilityDic, moveDic, learnset, gen, natureDic, level, cheats):
        self.__captureDate = datetime.now()
        self.__level = level
        self.__synched = True
        self.assign_gender(species, data)
        self.assign_shiny(cheats)
        self.assign_IV(cheats)
        self.assign_nature(natureDic)
        
        self.__ability = None
        self.assign_basics(species, data, abilityDic, moveDic, learnset, gen)
        self.__heldItem = None
        
        try:
            self.__moves = [random.choice(self.__movepool), None, None, None]
        except IndexError:
            # If movepool is empty
            self.__moves = [None, None, None, None]
    
    def __str__(self):
        return self.__name
    
    def assign_basics(self, species, data, abilityDic, moveDic, learnset, gen):
        self.__species = species
        self.__name = data[species]["name"]
        self.__dex = data[species]["num"]
        self.__types = data[species]["types"]
        self.__base = data[species]["baseStats"]
        self.assign_abilities(species, abilityDic, data)
        self.assign_moves(moveDic, learnset, gen)
        self.assign_evolutions(data)
    
    def assign_abilities(self, species, abilityDic, data):
        self.__abilityList = []
        for abilityName in data[species]["abilities"].values():
            for ability in abilityDic.values():
                if ability.get_name() == abilityName:
                    self.__abilityList.append(ability)
        
        if self.__ability is None:
            self.__ability = random.choice(self.__abilityList)
            self.__abilityIndex = self.__abilityList.index(self.__ability)
        else:
            try:
                self.__ability = self.__abilityList[self.__abilityIndex]
            except IndexError:
                self.__ability = random.choice(self.__abilityList)

    def assign_moves(self, moveDic, learnset, gen):
        log.info('(%s) Assigning moves.', self.get_name())
        
        self.__levelup = {}
        g = gen
        while self.__levelup == {}:
            for level in range(100):
                for move, infoList in learnset.items():
                    if str(g) + "L" + str(level+1) in infoList:
                        self.__levelup[move] = (moveDic[move], level)
            g -= 1
            
            if g == 0:
                break
        
        self.__TM = {}
        g = gen
        while self.__TM == {}:
            for move, infoList in learnset.items():
                if str(g) + "M" in infoList:
                    self.__TM[move] = moveDic[move]
            g -= 1

            if g == 0:
                break
        
        self.update_movepool()
    
    
    def update_movepool(self):
        log.info('(%s) Movepool updated.', self.get_name())
        
        self.__movepool = []
        for move, level in self.__levelup.values():
            if self.__level >= level:
                self.__movepool.append(move)
        
        for move in self.__TM.values():
            if move.get_unlocked() == True and move not in self.__movepool:
                self.__movepool.append(move)
                
    
    def assign_evolutions(self, data):
        evoList = []
        for species in data:
            # Check if pokemon is an evolution
            if "prevo" in data[species]:
                if data[species]["prevo"] == self.__name:
                    # Check if pokemon has correct gender
                    if "gender" in data[species]:
                        if data[species]["gender"] == self.__gender:
                            evoList.append(species)
                    else:
                        evoList.append(species)
        
        self.__evolutions = {}
        for species in evoList:
            self.__evolutions[species] = {}
        
            # Level
            if "evoLevel" in data[species]:
                self.__evolutions[species]["level"] = data[species]["evoLevel"]
            else:
                self.__evolutions[species]["level"] = 0
            # Method
            if "evoType" in data[species]:
                self.__evolutions[species]["type"] = data[species]["evoType"]
            else:
                self.__evolutions[species]["type"] = "levelup"
            # Item
            if "evoItem" in data[species]:
                self.__evolutions[species]["item"] = data[species]["evoItem"]
            else:
                self.__evolutions[species]["item"] = None
            # Special conditions
            if "evoCondition" in data[species]:
                self.__evolutions[species]["condition"] = data[species]["evoCondition"]
            else:
                self.__evolutions[species]["condition"] = None
            # Name
            self.__evolutions[species]["name"] = data[species]["name"]
                
    
    def assign_gender(self, species, data):
        if "gender" in data[species]:
            self.__gender = data[species]["gender"]
        elif "genderRatio" in data[species]:
            if random.uniform(0,1) < data[species]["genderRatio"]["M"]:
                self.__gender = "M"
            else:
                self.__gender = "F"
        else:
            if random.uniform(0,1) < 0.5:
                self.__gender = "M"
            else:
                self.__gender = "F"
        
    def assign_shiny(self, cheats):
        if cheats["Shiny"] == True or random.randint(1, 4096) == 1:
            self.__shiny = True
        else:
            self.__shiny = False
            
            
    def assign_IV(self, cheats):
        if cheats["IV"] == True:
            self.__IV = {stat: 31 for stat in ["HP", "Atk", "Def", "SpA", "SpD", "Spe"]}
        else:
            self.__IV = {stat: random.randint(0, 31) for stat in ["HP", "Atk", "Def", "SpA", "SpD", "Spe"]}

    
    def assign_nature(self, natureDic):
        self.__nature = random.choice(list(natureDic.keys()))
        self.__natureInfo = natureDic[self.__nature]
    
    
    def evolve(self, species, data, abilityDic, moveDic, learnset, gen):
        log.info('(%s) %s is evolving into %s.', self.get_name(), self.get_species(), species)
        self.assign_basics(species, data, abilityDic, moveDic, learnset, gen)
    
    
    def get_species(self):
        return self.__species
    def get_name(self):
        return self.__name
    def get_shiny(self):
        return self.__shiny
    def get_movepool(self):
        return self.__movepool
    def get_moves(self):
        return self.__moves
    def get_stats(self, stat=None):
        if stat is None:
            return self.__EV, self.__IV
        else:
            return self.__EV[stat], self.__IV[stat]
    def get_base(self, stat):
        return self.__base[stat.lower()]
    def get_nature(self):
        return self.__nature, self.__natureInfo
    def get_forme(self):
        return self.__forme
    def get_dex(self):
        return self.__dex
    def get_ability_list(self):
        return self.__abilityList
    def get_ability(self):
        return self.__ability
    def get_held_item(self):
        return self.__heldItem
    def get_types(self):
        return self.__types
    def get_gender(self):
        return self.__gender
    def get_level(self):
        return self.__level
    def get_evolutions(self):
        return self.__evolutions
    def get_synched(self):
        return self.__synched
    def get_capture_date(self):
        return self.__captureDate
    
    def set_move(self, move, slot):
        if move is None:
            log.info('(%s) Removed move slot %d.', self.get_name(), slot)
        else:
            log.info('(%s) Move slot %d changed to: %s.', self.get_name(), slot, move.get_name())
        self.__moves[slot] = move
    
    def set_ability(self, ability):
        log.info('(%s) Ability changed to: %s.', self.get_name(), ability.get_name())
        self.__ability = ability
        self.__abilityIndex = self.__abilityList.index(self.__ability)
    
    def set_held_item(self, item):
        if item is None:
            log.info('(%s) Removed held item.', self.get_name())
        else:
            log.info('(%s) Held item changed to: %s.', self.get_name(), item.get_name())
        self.__heldItem = item
    
    def set_synched(self, state):
        log.info('(%s) Synchronize changed to: %s.', self.get_name(), state)
        self.__synched = state
    
    def set_EV(self, EVSpread, stat=None):
        if stat is None:
            log.info('(%s) Loaded EV spread.', self.get_name())
            self.__EV = EVSpread.copy()
        else:
            log.info('(%s) %s EV changed to: %d.', self.get_name(), stat, EVSpread)
            self.__EV[stat] = EVSpread
    
    def set_IV(self, IVSpread, stat=None):
        if stat is None:
            log.info('(%s) Loaded IV spread.', self.get_name())
            self.__IV = IVSpread.copy()
        else:
            log.info('(%s) %s IV changed to: %d.', self.get_name(), stat, IVSpread)
            self.__IV[stat] = IVSpread
            
    def set_nature(self, nature, natureDic):
        log.info('(%s) Nature changed to: %s.', self.get_name(), nature)
        self.__nature = nature
        self.__natureInfo = natureDic[nature]
    
    def set_level(self, level):
        log.info('(%s) Level changed to: %d.', self.get_name(), level)
        self.__level = level
        self.update_movepool()
    
    def set_gender(self, gender):
        self.__gender = gender
    
    def set_shiny(self, shiny):
        self.__shiny = shiny
        
    def set_capture_date(self, captureDate):
        self.__captureDate = datetime.strptime(captureDate, "%Y-%m-%d %H:%M:%S")