import logging as log

class Adventure():
    def __init__(self, path, title):
        self.__steps = {}
        self.__stages = []
        self.__path = path
        self.__title = title
        
        self.__currentStep = None
        
    def add_step(self, stage, name, text, isContinuation, imagePath):
        if stage not in self.__stages:
            self.__stages.append(stage)
        
        self.__steps[name] = Step(stage, name, text, isContinuation, imagePath)
        
        # Initialize current step
        if self.__currentStep is None:
            self.__currentStep = self.__steps[name]
    
    def set_current(self, name):
        self.__currentStep = self.__steps[name]
    def get_current(self):
        return self.__currentStep
    def next_step(self):
        stepList = list(self.__steps.values())
        
        if self.__currentStep is not None:
            currentIndex = stepList.index(self.__currentStep)
            
            if len(stepList) == currentIndex + 1:
                self.__currentStep = stepList[0]
            else:
                self.__currentStep = stepList[currentIndex + 1]
        
        else:
            self.__currentStep = stepList[0]
    
    def get_path(self):
        return self.__path
    def get_title(self):
        return self.__title
    def get_steps(self):
        return self.__steps
    def get_stages(self):
        return self.__stages
    
    def get_step(self, key):
        if key in self.__steps:
            return self.__steps[key]
        else:
            log.error('No step named %s in the adventure.', key)

class Step():
    def __init__(self, stage, name, text, isContinuation, imagePath):
        self.__stage = stage
        self.__options = {}
        
        self.__name = name
        self.__text = text
        self.__imagePath = imagePath
        
        if isContinuation == "TRUE":
            self.__isContinuation = True
        else:
            self.__isContinuation = False
        
    def add_option(self, name, optionDict):
        self.__options[name] = Option(name, optionDict)
        
        log.debug('Added step %s with unlock dictionary:', name)
        log.debug(str(optionDict))
    
    def get_stage(self):
        return self.__stage
    
    def get_name(self):
        return self.__name
    def get_text(self):
        return self.__text
    def get_continuation(self):
        return self.__isContinuation
    def get_image(self):
        return self.__imagePath
     
    def get_options(self):
        return self.__options
        
class Option():
    def __init__(self, name, optionDict):
        self.__name = name
        self.__unlocks = optionDict
    
    def get_unlocks(self):
        return self.__unlocks
    def get_name(self):
        return self.__name