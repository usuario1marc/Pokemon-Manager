import json
import csv
import ast

from pokemon import Pokemon
from generic import Generic
from move import Move
from item import Item
from adventure import Adventure

import logging as log
log.basicConfig(level=log.WARNING, format='[%(levelname)s] %(message)s')

class Manager():
    
    def __init__(self):
        log.debug('Manager instanced.')
        
        self.initialize_default_parameters()
        self.load_data()
        
        try:
            self.load_save("saves/__temp__.json")
        except FileNotFoundError:
            log.warning('Temporal save file could not be found')
        except:
            log.error('An unexpected error ocurred with the temporal save file.')
        
    def initialize_default_parameters(self):
        self.__POKEMON = []
        self.__gen = 9
        self.__levelcap = 1
        self.__defaultEVSpread = {'HP': 0, 'Atk': 0, 'Def': 0, 'SpA': 0, 'SpD': 0, 'Spe': 0}
        self.__adventure = None
        self.__excludedFormes = self.read_json("data/formes.txt")["notIncluded"]
        self.__generationSeparations = [151, 251, 386, 493, 649, 721, 809, 905, 1025]
        self.__sortModes = ["Date", "Name", "Pokédex"]
        self.__sortMode = self.__sortModes[0]
        self.__cheats = {"Shiny": False, "IV": False, "Nature": False, "Ability": True}
        self.__adventurePreferences = {"Generate": True, "Unlock": True, "Level": True, "Size": 300}
        
###############################################################################
    """
            WRITE AND READ DATA
    """
###############################################################################

    def read_json(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    
    def read_csv(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            data = [row for row in reader]
        return data
    
    def load_data(self):
        log.info('Data loaded.')
        
        # Pokedex & learnsets
        self.__POKEDEX = self.read_json("data/pokedex.txt")
        self.__LEARNSETS = self.read_json("data/learnsets.txt")
        self.__NATURES = self.read_json("data/natures.txt")
        
        # Abilities
        self.__ABILITIES = {}
        abilityData = self.read_json("data/abilities.txt")
        for ability in abilityData:
            self.__ABILITIES[ability] = Generic(ability, abilityData)
            
        # Moves
        self.__MOVES = {}
        moveData = self.read_json("data/moves.txt")
        for move in moveData:
            self.__MOVES[move] = Move(move, moveData, self.__LEARNSETS, self.__gen)
            
        # Held items
        self.__ITEMS = {}
        itemData = self.read_json("data/items.txt")
        for item in itemData:
            self.__ITEMS[item] = Item(item, itemData)
        
    def write_save(self, path):
        # Parse pokemon objects into a list that can be converted to JSON file
        monList = []
        for pokemon in self.__POKEMON:
            monDict = {}
            monDict["species"] = pokemon.get_species()
            monDict["level"] = pokemon.get_level()
            monDict["synched"] = pokemon.get_synched()
            monDict["gender"] = pokemon.get_gender()
            monDict["shiny"] = pokemon.get_shiny()
            monDict["ability"] = pokemon.get_ability().get_key()
            if pokemon.get_held_item() is not None:
                monDict["item"] = pokemon.get_held_item().get_key()
            monDict["moves"] = [move.get_key() for move in pokemon.get_moves() if move is not None]
            monDict["EVs"], monDict["IVs"] = pokemon.get_stats()
            monDict["nature"] = pokemon.get_nature()
            monDict["date"] = pokemon.get_capture_date().strftime("%Y-%m-%d %H:%M:%S")
            
            monList.append(monDict)
        
        unlockedTMs = [tm.get_key() for tm in self.__MOVES.values() if tm.get_unlocked() == True]
        unlockedItems = [item.get_key() for item in self.__ITEMS.values() if item.get_unlocked() == True]
        
        if self.__adventure is not None:
            adventurePath = self.__adventure.get_path()
            currentStep = self.__adventure.get_current().get_name()
        else:
            adventurePath = None
            currentStep = None
        
        settings = {"cheats":self.__cheats, "adventure":self.__adventurePreferences}
        
        # Save current level cap, generation and default EV spread
        saveDict = {"pokemon":monList, "levelcap":self.__levelcap, "gen":self.__gen,
                    "defEV":self.__defaultEVSpread, "TMs":unlockedTMs, "items":unlockedItems,
                    "adventure":adventurePath, "step":currentStep, "settings":settings}
        
        # Dump everything
        with open(path, 'w') as f:
            json.dump(saveDict, f)
            
        log.info('Save data saved in path %s', path)
    
    def load_save(self, path):
        log.info('Opening save data in %s', path)
        
        # Open JSON file
        saveDict = self.read_json(path)
        
        # Initialize generation, levelcap and default EV spread
        self.__levelcap = saveDict["levelcap"]
        self.set_gen(saveDict["gen"])
        self.__defaultEVSpread = saveDict["defEV"]
        
        # Moves
        self.__MOVES = {}
        moveData = self.read_json("data/moves.txt")
        for move in moveData:
            self.__MOVES[move] = Move(move, moveData, self.__LEARNSETS, self.__gen)
        
        # Unlock items and TMs
        self.empty_bag()
        for key in saveDict["TMs"]:
            self.__MOVES[key].set_unlocked(True)
        for key in saveDict["items"]:
            self.__ITEMS[key].set_unlocked(True)
        
        # Parse lists into pokemon objects
        monList = saveDict["pokemon"]
        self.__POKEMON = []
        for monDict in monList:
            self.new_pokemon(monDict["species"])
            pokemon = self.__POKEMON[-1]
            
            pokemon.set_level(monDict["level"])
            pokemon.set_synched(monDict["synched"])
            pokemon.set_ability(self.__ABILITIES[monDict["ability"]])
            if "item" in monDict:
                pokemon.set_held_item(self.__ITEMS[monDict["item"]])
            if "moves" in monDict:
                for slot, move in enumerate(monDict["moves"]):
                    pokemon.set_move(self.__MOVES[move], slot)
            pokemon.set_EV(monDict["EVs"])
            pokemon.set_IV(monDict["IVs"])
            pokemon.set_nature(monDict["nature"][0], self.__NATURES)
            pokemon.set_gender(monDict["gender"])
            pokemon.set_shiny(monDict["shiny"])
            pokemon.set_capture_date(monDict["date"])
        self.update_pokemon_movepools()
            
        # Adventure
        if saveDict["adventure"] is not None:
            try:
                self.load_adventure(saveDict["adventure"])
                self.__adventure.set_current(saveDict["step"])
            except AttributeError:
                log.error('Adventure file has changed path.')
                self.__adventure = None
            except KeyError:
                log.error('Adventure step not recognised.')
                self.__adventure = None
            
        # Settings
        self.__cheats = saveDict["settings"]["cheats"]
        self.__adventurePreferences = saveDict["settings"]["adventure"]
    
    def parse_option_dictionary(self, stepDict, option, unlockable):
        if stepDict[unlockable] == "":
            return None
        elif option not in ast.literal_eval(stepDict[unlockable]):
            return None
        else:
            return ast.literal_eval(stepDict[unlockable])[option]
    
    def load_adventure(self, path):
        try:
            general = self.read_json(f"{path}/general.txt")
            steps = self.read_csv(f"{path}/steps.csv")
        
        except FileNotFoundError:
            log.error('No adventure found in %s', path)
            return
        
        title = general.get("title", "Adventure")
        gen = general.get("gen")
        
        if gen != self.__gen:
            self.set_gen(gen)
            self.wipe_save()
        
        self.__adventure = Adventure(path, title)
        
        try:
            for step in steps:
                
                key = step["title"]
                self.__adventure.add_step(step["stage"], key, step["text"], step["continuation"], step["image"])
                
                if step["options"] != "":
                    for option in ast.literal_eval(step["options"]):
                        
                        optionDict = {}
                        for unlockable in ["new levelcap", "items", "tms", "pokemon"]:
                            value = self.parse_option_dictionary(step, option, unlockable)
                            
                            if value is not None:
                                optionDict[unlockable] = value
                            
                        self.__adventure.get_step(key).add_option(option, optionDict)
        
        except KeyError:
            log.warning('Adventure steps file is corrupt.')
            
###############################################################################
    """
            MANAGE POKÉMON
    """
###############################################################################
    
    def empty_bag(self):
        for item in self.__ITEMS.values():
            item.set_unlocked(False)
        for move in self.__MOVES.values():
            move.set_unlocked(False)

    def wipe_save(self):
        self.__POKEMON = []
        self.__levelcap = 1
        self.__adventure = None
        self.load_data()
    
    def sort_list(self, sort_mode):
        if sort_mode == "Date":
            self.__POKEMON = sorted(self.__POKEMON, key=lambda mon: mon.get_capture_date())
        if sort_mode == "Name":
            self.__POKEMON = sorted(self.__POKEMON, key=lambda mon: mon.get_name())
        if sort_mode == "Pokédex":
            self.__POKEMON = sorted(self.__POKEMON, key=lambda mon: mon.get_dex())
    
    def new_pokemon(self, species):
        log.info('New pokémon created: %s', species)
        
        try:
            learnset = self.__LEARNSETS[species]["learnset"]
        except KeyError:
            log.error('Selected pokémon does not have a learnset.')
            learnset = {}
        
        self.__POKEMON.append(Pokemon(species, self.__POKEDEX, self.__ABILITIES,
                                      self.__MOVES, learnset, self.__gen, self.__NATURES,
                                      self.__levelcap, self.__cheats))
        
        self.__POKEMON[-1].set_EV(self.__defaultEVSpread)
    
    def get_pokemon(self):
        return self.__POKEMON
    
    def delete_pokemon(self, pokemon):
        if pokemon in self.__POKEMON:
            self.__POKEMON.remove(pokemon)
            log.info('Pokémon deleted: %s', pokemon.get_name())
        else:
            log.error('Cannot delete %s. Pokémon not found.', pokemon.get_name())
        
    def all_pokemon_names(self):
        maxID = self.__generationSeparations[self.__gen-1]
        pokemonDict = {}
        
        for species in self.__POKEDEX:
            if 0 < self.__POKEDEX[species]["num"] <= maxID:
                
                if "forme" in self.__POKEDEX[species]:
                    if self.__POKEDEX[species]["forme"] in self.__excludedFormes:
                        ignoreMon = True
                    else:
                        ignoreMon = False
                else:
                    ignoreMon = False
                
                if ignoreMon == False:                   
                    pokemonDict[self.__POKEDEX[species]["name"]] = species
        
        log.debug('Requested pokémon names. %d species returned.', len(pokemonDict))
        return pokemonDict
    
    def all_items(self):
        return {item.get_name():item for item in self.__ITEMS.values()}
    def all_tms(self):
        return {move.get_name():move for move in self.__MOVES.values() if move.get_TM() == True}
    
    def unlocked_items(self):
        return [item.get_name() for item in self.__ITEMS.values() if item.get_unlocked() == True]
    def unlocked_tms(self):
        return [move.get_name() for move in self.__MOVES.values() if move.get_unlocked() == True]
    
    def get_excluded_formes(self):
        # Formes not included in the program (dynamax, megas, etc.)
        return self.__excludedFormes
    
    def update_pokemon_movepools(self):
        for pokemon in self.__POKEMON:
            pokemon.update_movepool()
    
    def get_sort_modes(self):
        return self.__sortModes
    def get_sort_mode(self):
        return self.__sortMode
    
    def get_levelcap(self):
        return self.__levelcap
    def get_gen(self):
        return self.__gen
    def get_cheats(self):
        return self.__cheats
    def get_adventure_preferences(self):
        return self.__adventurePreferences
    
    def get_natures(self):
        return self.__NATURES
    
    def set_levelcap(self, level):
        log.info('Level cap set to: %d.', level)
        self.__levelcap = level
        self.sync_pokemon_levels()
    def set_gen(self, gen):
        log.info('Generation set to: %d.', gen)
        self.__gen = gen
    def set_cheats(self, cheats):
        self.__cheats = cheats
    def set_adventure_preferences(self, preferences):
        self.__adventurePreferences = preferences
    def set_default_EV_spread(self, EVspread):
        self.__defaultEVSpread = EVspread
    
    def sync_pokemon_levels(self):
        for pokemon in self.__POKEMON:
            if pokemon.get_synched() == True:
                pokemon.set_level(self.__levelcap)
    
    def evolve(self, prevo, evoSpecies):
        learnset = self.__LEARNSETS[evoSpecies]["learnset"]
        prevo.evolve(evoSpecies, self.__POKEDEX, self.__ABILITIES, self.__MOVES, learnset, self.__gen)
        return prevo
    
    def get_adventure(self):
        return self.__adventure
    
    def GET_POKEDEX(self):
        return self.__POKEDEX