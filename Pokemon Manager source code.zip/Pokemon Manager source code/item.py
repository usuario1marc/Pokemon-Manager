from generic import Generic

class Item(Generic):
    def __init__(self, key, data):
        super().__init__(key, data)
        self.__isUnlocked = False
    
    def set_unlocked(self, state):
        self.__isUnlocked = state
        
    def get_unlocked(self):
        return self.__isUnlocked