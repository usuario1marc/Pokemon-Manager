from generic import Generic

class Move(Generic):
    def __init__(self, key, data, learnsets, gen):
        super().__init__(key, data)
        
        self.__type = data[key]["type"]
        self.__basePower = data[key]["basePower"]
        self.__accuracy = data[key]["accuracy"]
        self.__category = data[key]["category"]
        self.__pp = data[key]["pp"]
        
        if self.__basePower == 0:
            self.__basePower = "-"
        if self.__accuracy == 1:
            self.__accuracy = "-"
        
        self.__isUnlocked = False
        self.__isTM = self.check_TM(learnsets, gen)
    
    def check_TM(self, learnsets, gen):
        for pokemon in learnsets:
            if "learnset" in learnsets[pokemon]:
                if self.get_key() in learnsets[pokemon]["learnset"].keys():
                    if str(gen) + "M" in learnsets[pokemon]["learnset"][self.get_key()]:
                        return True
        return False
    
    def set_unlocked(self, state):
        self.__isUnlocked = state
    
    def get(self):
        return self.__type, self.__basePower, self.__accuracy, self.__category, self.__pp
    
    def get_unlocked(self):
        return self.__isUnlocked
    
    def get_TM(self):
        return self.__isTM