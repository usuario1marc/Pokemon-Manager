class Generic():
    def __init__(self, key, data):
        self.__key = key
        self.__name = data[key]["name"]
        
        if "shortDesc" in data[key]:
            self.__description = data[key]["shortDesc"]
        elif "desc" in data[key]:
            self.__description = data[key]["desc"]
        else:
            self.__description = "No description available."
            
    def __str__(self):
        return self.__name
        
    def get_key(self):
        return self.__key
    def get_name(self):
        return self.__name
    def get_description(self):
        return self.__description