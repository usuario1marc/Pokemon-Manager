import customtkinter as ctk
from tkinter import filedialog
from CTkListbox import CTkListbox
from PIL import Image
from manager import Manager
import random
import logging as log

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.iconbitmap("assets/manager.ico")
        self.title("Pokémon Manager")
        self.geometry("1000,600")
        self.minsize(1000,600)
        
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("assets/ctk_color_theme.json")
        
        self.__m = Manager()
        self.build_widgets()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def build_widgets(self):
        # MAIN FRAME #
        self.__mainFrame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.__mainFrame.pack(expand=True, fill="both")
        
        # Top frame
        self.__topFrame = ctk.CTkFrame(self.__mainFrame, fg_color="gray10", corner_radius=0)
        self.__topFrame.pack(expand=False, fill="both")
        self.__topFrame.grid_columnconfigure(0, weight=1)
        
        # --- Title
        titleFont = ctk.CTkFont(size=20, weight="bold")
        self.__title = ctk.CTkLabel(self.__topFrame, text="Pokémon Manager", font=titleFont, anchor="w")
        self.__title.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        self.add_menus()
        
        # Bottom frame
        self.__bottomFrame = ctk.CTkFrame(self.__mainFrame, corner_radius=0)
        self.__bottomFrame.pack(expand=True, fill="both")
        
        # --- Right frame
        self.__rightFrame = ctk.CTkFrame(self.__bottomFrame, fg_color="transparent")
        self.__rightFrame.pack(side="right", expand=True, fill="both")
        
        # --- --- Pokemon information
        self.__pokemonInformationFrame = PokemonInformation(self.__rightFrame, self)
        self.__pokemonInformationFrame.pack(side="right", expand=True, fill="both", padx=(0,10), pady=(0,10))
        
        # --- Left frame
        self.__leftFrame = ctk.CTkFrame(self.__bottomFrame)
        self.__leftFrame.pack(side="left", expand=False, fill="both", padx=10, pady=(18,10))
        
        # --- --- Scrolling list
        self.__pokemonList = PokemonList(self.__leftFrame, self)
        self.__pokemonList.configure_function(self.__pokemonList.show_info, False)
        self.__pokemonList.pack(expand=True, fill="both", padx=10, pady=(10,0))
        
        # --- --- Bottom button frame
        self.__bottomButtonFrame = ctk.CTkFrame(self.__leftFrame, fg_color="transparent")
        self.__bottomButtonFrame.pack(side="bottom", expand=False, fill="both", padx=10, pady=10)
        
        # --- --- --- Add pokémon button
        self.__addPokemonButton = ctk.CTkButton(self.__bottomButtonFrame, text="Add pokémon", width=200)
        self.__addPokemonButton.pack()
        self.__addPokemonButton.configure(command=self.new_pokemon_window)
        
        # --- --- --- Export button
        self.__exportButton = ctk.CTkButton(self.__bottomButtonFrame, text="Export team", width=200)
        self.__exportButton.pack(pady=(10,0))
        self.__exportButton.configure(command=self.export_team)
        
        # --- --- Sort mode
        sortModes = self.__m.get_sort_modes()
        sortFont = ctk.CTkFont(size=12)
        self.__sortingButtons = ctk.CTkSegmentedButton(self.__leftFrame, values=sortModes, font=sortFont, height=20)
        self.__sortingButtons.configure(command=self.sort_list)
        self.__sortingButtons.pack(expand=False, fill="both", padx=10, pady=10)
        self.__sortingButtons.set(self.__m.get_sort_mode())
        
        # ADVENTURE FRAME #
        self.__adventureFrame = AdventureViewer(self)
    
    def add_menus(self):
        self.__adventureButton = ctk.CTkButton(self.__topFrame, text="Adventure",
        width=100, corner_radius=0, command=self.show_adventure)
        self.__adventureButton.grid(row=0, column=7, sticky="nsew")
        
        self.__levelButton = ctk.CTkButton(self.__topFrame, text="Settings",
        width=70, corner_radius=0, fg_color="gray10", command=self.options_window)
        self.__levelButton.grid(row=0, column=6, sticky="nsew")
        
        self.__itemsButton = ctk.CTkButton(self.__topFrame, text="Items",
        width=70, corner_radius=0, fg_color="gray10", command=self.select_items_window)
        self.__itemsButton.grid(row=0, column=5, sticky="nsew")
        
        self.__tmsButton = ctk.CTkButton(self.__topFrame, text="TMs",
        width=70, corner_radius=0, fg_color="gray10", command=self.select_tms_window)
        self.__tmsButton.grid(row=0, column=4, sticky="nsew")
        
        self.__levelButton = ctk.CTkButton(self.__topFrame, text="Level",
        width=70, corner_radius=0, fg_color="gray10", command=self.levelcap_window)
        self.__levelButton.grid(row=0, column=3, sticky="nsew")
        
        self.__saveButton = ctk.CTkButton(self.__topFrame, text="Save",
        width=70, corner_radius=0, fg_color="gray10", command=self.write_save)
        self.__saveButton.grid(row=0, column=2, sticky="nsew")
        
        self.__saveButton = ctk.CTkButton(self.__topFrame, text="Load",
        width=70, corner_radius=0, fg_color="gray10", command=self.load_save)
        self.__saveButton.grid(row=0, column=1, sticky="nsew")
    
    def on_closing(self):
        self.__m.write_save("saves/__temp__.json")
        self.destroy()
        self.quit()
    
    def sort_list(self, event):
        sort_mode = self.__sortingButtons.get()
        self.__m.sort_list(sort_mode)
        self.update_pokemon_list()
    def new_pokemon_window(self):
        self.__pokemonSelector = NewPokemonSelector(self)
    def export_team(self):
        self.__teamExporter = TeamExporter(self)
    
    def write_save(self):
        fileName = filedialog.asksaveasfilename(initialdir="saves", title="Choose save data directory",
                                                defaultextension=".json", filetypes=[("json files", "*.json"),("All files", "*.*")])
        if fileName:
            self.__m.write_save(fileName)
        else:
            log.warning('No file selected.')
    
    def load_save(self):
        fileName = filedialog.askopenfilename(initialdir="saves", title="Select a save data file")
        if fileName:
            self.__m.load_save(fileName)
            self.update_pokemon_list()
            self.__pokemonInformationFrame.hide_widgets()
            self.__adventureFrame.update()
        else:
            log.warning('No file selected.')
    
    def show_adventure(self):
        self.__mainFrame.pack_forget()
        self.__adventureFrame.pack(expand=True, fill="both")
    def show_main(self):
        self.__adventureFrame.pack_forget()
        self.__mainFrame.pack(expand=True, fill="both")
    
    def get_adventure_viewer(self):
        return self.__adventureFrame
    def get_pokemon_information(self):
        return self.__pokemonInformationFrame
    
    def select_items_window(self):
        self.__itemSelector = ItemSelector(self, mode="item")
    def select_tms_window(self):
        self.__tmSelector = ItemSelector(self, mode="tm")
    def levelcap_window(self):
        self.__levelcapSelector = LevelCapSelector(self)
    def options_window(self):
        self.__optionsMenu = OptionsMenu(self)
        
    def update_pokemon_list(self):
        self.__pokemonList.build_items()
    
    def update_pokemon_info(self, pokemon=None):      
        self.__pokemonInformationFrame.update(pokemon)
    def reset_pokemon_info(self):
        self.__pokemonInformationFrame.hide_widgets()
        
    def get_manager(self):
        return self.__m        
        
class PokemonList(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color="transparent", corner_radius=0)
        self.__app = app
        self.__m = app.get_manager()
        self.__pokemonDict = self.__m.all_pokemon_names()
        self.__listBox = CTkListbox(self)
    
    def configure_function(self, function=None, multiple=True):
        self.__function = function
        self.__multiple = multiple
        self.build_items()
    
    def build_items(self):
        self.__listBox.destroy()
        self.__listBox = CTkListbox(self, multiple_selection=self.__multiple, border_width=2, scrollbar_button_color="gray16")
        if self.__function is not None:
            self.__listBox.configure(command=self.__function)
        self.__listBox.pack(expand=True, fill="both")
        
        self.__pokemonList = self.__m.get_pokemon()
        for pokemon in self.__pokemonList:
            self.__listBox.insert("end", pokemon.get_name(), update=False)
        self.__listBox.update()
    
    def show_info(self, *args):
        index = self.__listBox.curselection()
        pokemon = self.__pokemonList[index]
        self.__app.update_pokemon_info(pokemon)
    
    def get(self):
        return self.__listBox.get()
    
###############################################################################
"""
        TOPLEVEL WINDOWS FOR SELECTORS
"""
###############################################################################

class Selector(ctk.CTkToplevel):
    def __init__(self, parent, items):
        super().__init__(parent)
        self.transient(parent)
        self.grab_set()
        self.geometry("500x400")
        self.minsize(400,300)
        self.title("Pokémon Manager")
        
        self.__multiple = False     # Allow multiple selection
        self.__selected = []        # Memory of all selected items
        self.__items = items
        self.__filteredList = []
        
        self.__itemsPerPage=50
        self.build_widgets()
        self.update_list()
    
    def build_widgets(self):
        titleFont = ctk.CTkFont(size=14, weight="bold")
        self.__label = ctk.CTkLabel(self, text="", font=titleFont)
        self.__label.pack(expand=False, fill="both", pady=(5,0))
        
        self.__topFrame = ctk.CTkFrame(self)
        self.__topFrame.pack(expand=False, fill="both", padx=5, pady=5)
        
        self.__string = ctk.StringVar()
        self.__searchBar = ctk.CTkEntry(self.__topFrame, textvariable=self.__string, border_width=2)
        self.__searchBar.pack(side="left", expand=True, fill="both", padx=5, pady=5)
        
        self.__searchButton = ctk.CTkButton(self.__topFrame, text="Search", width=100)
        self.__searchButton.configure(command=self.update_list)
        self.__searchButton.pack(side="left", expand=False, fill="both", padx=5, pady=5)
        
        self.__listBoxFrame = ctk.CTkFrame(self)
        self.__listBoxFrame.pack(expand=True, fill="both", padx=5, pady=5)
        self.__listBox = CTkListbox(self.__listBoxFrame)
        
        self.__bottomFrame = ctk.CTkFrame(self)
        self.__bottomFrame.pack(expand=False, fill="both", padx=5, pady=5)
        
        self.__previousButton = ctk.CTkButton(self.__bottomFrame, text="Previous page", width=100, fg_color="#343638")
        self.__previousButton.configure(command=lambda:self.change_page(-1))
        self.__previousButton.pack(side="left", expand=False, fill="both", padx=5, pady=5)
        
        self.__confirmButton = ctk.CTkButton(self.__bottomFrame, text="")
        self.__confirmButton.pack(side="left", expand=True, fill="both", padx=5, pady=5)
        
        self.__nextButton = ctk.CTkButton(self.__bottomFrame, text="Next page", width=100, fg_color="#343638")
        self.__nextButton.configure(command=lambda:self.change_page(1))
        self.__nextButton.pack(side="left", expand=False, fill="both", padx=5, pady=5)
    
    def build_items(self):
        self.__listBox.destroy()
        self.__listBox = CTkListbox(self.__listBoxFrame, border_width=2)
        self.__listBox.pack(expand=True, fill="both", padx=5, pady=5)
                
        for index, item in enumerate(self.__filteredList):
            if self.__page*self.__itemsPerPage <= index < (self.__page+1)*self.__itemsPerPage:
                self.__listBox.insert("end", item, update=False)
        
        self.__listBox.update()
        self.update_multiple_selection()
        self.select_selection()
        self.update_buttons()
    
    def update_multiple_selection(self):
        self.__listBox.configure(multiple_selection=self.__multiple)
    
    def select_selection(self):
        # Select all items saved in selected list
        for index, item in enumerate(self.__filteredList):
            if self.__page*self.__itemsPerPage <= index < (self.__page+1)*self.__itemsPerPage:
                if item in self.__selected:
                    self.__listBox.activate(index - self.__page*self.__itemsPerPage)
    
    def update_list(self, *args):
        self.save_selection()
        
        searchTerm = self.__string.get().lower()
        self.__filteredList = [item for item in self.__items if searchTerm in item.lower()]
        self.__page = 0
        
        self.build_items()
    
    def change_page(self, amount):
        self.save_selection()
        self.freeze_buttons()
        
        self.__page += amount
        
        self.build_items()
    
    def freeze_buttons(self):
        self.__previousButton.configure(state="disabled")
        self.__nextButton.configure(state="disabled")
    
    def update_buttons(self):
        if self.__page == 0:
            self.__previousButton.configure(state="disabled")
        else:
            self.__previousButton.configure(state="normal")
            
        if self.__page == len(self.__filteredList)//self.__itemsPerPage:
            self.__nextButton.configure(state="disabled")
        else:
            self.__nextButton.configure(state="normal")
    
    def save_selection(self):
        # Save new values in selected list, remove values that are de-selected
        if self.__listBox.get() is not None:
            
            if self.__multiple == False:
                self.__selected = [self.__listBox.get()]
            
            else:
                for index, item in enumerate(self.__filteredList):
                    if self.__page*self.__itemsPerPage <= index < (self.__page+1)*self.__itemsPerPage:
                        
                        if item in self.__selected and item not in self.__listBox.get():
                            self.__selected.remove(item)
                        if item not in self.__selected and item in self.__listBox.get():
                            self.__selected.append(item)
    
    def configure_widgets(self, label, button, function, multiple):
        self.__label.configure(text=label)
        self.__confirmButton.configure(text=button, command=function)
        self.__multiple = multiple
        self.update_multiple_selection()
    
    def get_selection(self):
        return self.__selected
    
    def set_selection(self, selection):
        self.__selected = selection
      
class NewPokemonSelector(Selector):
    def __init__(self, app):
        self.__m = app.get_manager()
        self.__app = app
        self.__pokemonDict = self.__m.all_pokemon_names()
        super().__init__(app, list(self.__pokemonDict.keys()))
        self.configure_widgets(label="Choose a pokémon", button="Add pokémon", function=self.select_pokemon, multiple=False)
    
    def select_pokemon(self):
        self.save_selection()
        selection = self.get_selection()
        if len(selection) == 0:
            return
        pokemon = selection[0]
        self.__m.new_pokemon(self.__pokemonDict[pokemon])
        self.__app.sort_list(None)
        self.destroy()
        
              
class ItemSelector(Selector):
    def __init__(self, app, mode):
        self.__m = app.get_manager()
        self.__app = app
        
        if mode == "item":
            self.__itemDict = self.__m.all_items()
            selection = self.__m.unlocked_items()
            label = "Select items"
        
        if mode == "tm":
            self.__itemDict = self.__m.all_tms()
            selection = self.__m.unlocked_tms()
            label = "Select TMs"
        
        button = "Save changes"
        
        super().__init__(app, list(self.__itemDict.keys()))
        self.configure_widgets(label, button, function=self.save_items, multiple=True)
        self.set_selection(selection)
        self.select_selection()
    
    def save_items(self):
        self.save_selection()
        selection = self.get_selection()
        for itemName, item in self.__itemDict.items():
            if itemName in selection:
                item.set_unlocked(True)
            else:
                item.set_unlocked(False)
        self.__m.update_pokemon_movepools()
        self.__app.update_pokemon_info()
        self.destroy()
        
        
class AdventureStepSelector(Selector):
    def __init__(self, app):
        self.__m = app.get_manager()
        self.__app = app
        steps = self.__m.get_adventure().get_steps()
        super().__init__(app, list(steps.keys()))
        self.configure_widgets(label="Select a step", button="Go to step", function=self.set_step, multiple=False)
    
    def set_step(self):
        self.save_selection()
        selection = self.get_selection()
        if len(selection) == 0:
            return
        step = selection[0]
        self.__m.get_adventure().set_current(step)
        self.__app.get_adventure_viewer().update()
        self.destroy()

class LevelCapSelector(ctk.CTkToplevel):
    def __init__(self, app):
        super().__init__(app)
        self.transient(app)
        self.grab_set()
        
        self.__app = app
        self.__m = app.get_manager()
        self.__levelcap = self.__m.get_levelcap()
        
        self.title("Pokémon Manager")
        self.geometry("300x150")
        self.resizable(False, False)
        self.build_widgets()
        self.update_buttons()
    
    def build_widgets(self):
        titleFont = ctk.CTkFont(size=14, weight="bold")
        self.__label = ctk.CTkLabel(self, text="Change the current level cap", font=titleFont)
        self.__label.pack(padx=20, pady=5)
        
        self.__frame = ctk.CTkFrame(self, corner_radius=0)
        self.__frame.pack(expand=True, fill="both")
        self.__frame.grid_rowconfigure(0, weight=1)
        self.__frame.grid_columnconfigure(1, weight=1)
        
        bigFont = ctk.CTkFont(size=18)
        self.__minusButton = ctk.CTkButton(self.__frame, text="-", width=30, height=30,
                                           font=bigFont, command=lambda:self.on_button_press(-1))
        self.__minusButton.grid(row=0, column=0, padx=(50, 10), pady=10)
        
        self.__plusButton = ctk.CTkButton(self.__frame, text="+", width=30, height=30,
                                          font=bigFont, command=lambda:self.on_button_press(1))
        self.__plusButton.grid(row=0, column=2, padx=(10, 50), pady=10)
        
        self.__string = ctk.StringVar()
        self.__string.set(self.__levelcap)
        self.__string.trace("w", self.on_entry_changed)
        self.__entry = ctk.CTkEntry(self.__frame, textvariable=self.__string, height=30, border_width=2)
        self.__entry.grid(row=0, column=1, sticky="ew")
        
    def on_entry_changed(self, *args):
        text = self.__string.get()
        
        try:
            level = int(text)
            if 1 <= level <= 100:
                self.__levelcap = level
            elif level > 100:
                self.__string.set(str(100))
                self.__levelcap = 100
            else:
                self.__string.set(str(1))
                self.__levelcap = 1
        
            self.update_levelcap()
            self.update_buttons()
            
        except ValueError:
            # Input is not a number
            if text != "":
                self.__string.set(str(self.__levelcap))
    
    def on_button_press(self, step):
        self.__string.set(self.__levelcap + step)
        
    def update_levelcap(self):
        self.__m.set_levelcap(self.__levelcap)
        self.__app.update_pokemon_info()
    
    def update_buttons(self):
        if self.__levelcap == 1:
            self.__minusButton.configure(state="disabled")
        else:
            self.__minusButton.configure(state="normal")
        
        if self.__levelcap == 100:
            self.__plusButton.configure(state="disabled")
        else:
            self.__plusButton.configure(state="normal")

class EvolutionSelector(ctk.CTkToplevel):
    def __init__(self, app, pokemon):
        super().__init__(app)
        self.transient(app)
        self.grab_set()
        
        self.__pokemon = pokemon
        self.__app = app
        self.__m = app.get_manager()
        
        self.title("Pokémon Manager")
        self.geometry("600x400")
        self.minsize(550,250)
        self.build_widgets()
    
    def build_widgets(self):
        evoDict = self.__pokemon.get_evolutions()
        
        titleFont = ctk.CTkFont(size=14, weight="bold")
        self.__title = ctk.CTkLabel(self, text="Pick an evolution", font=titleFont)
        self.__title.pack(expand=False, fill="both", padx=20, pady=5)
        
        self.__bottomFrame = ctk.CTkFrame(self, corner_radius=0)
        self.__bottomFrame.pack(expand=True, fill="both")
        
        self.__scrollingFrame = ctk.CTkScrollableFrame(self.__bottomFrame)
        self.__scrollingFrame.pack(expand=True, fill="both", padx=20, pady=20)
        
        for species, evoInfo in evoDict.items():
            evoLevel, evoType, evoItem, evoCondition, evoName = \
            evoInfo["level"], evoInfo["type"], evoInfo["item"], evoInfo["condition"], evoInfo["name"]
            
            string = f"Evolves via: {evoType}"
            if evoLevel != 0:
                string += f" at level {evoLevel}"
            if evoItem is not None:
                string += f" using the item: {evoItem}"
            if evoCondition is not None:
                string += f" {evoCondition}"
            string += "."
            
            bigFont = ctk.CTkFont(size=16, weight="bold")
            name = ctk.CTkLabel(self.__scrollingFrame, text=evoName, font=bigFont, anchor="w")
            name.pack(expand=False, fill="both", padx=20, pady=(10,0))
            
            label = ctk.CTkLabel(self.__scrollingFrame, text=string, anchor="w", justify="left")
            label.pack(expand=False, fill="both", padx=20)
            
            button = ctk.CTkButton(self.__scrollingFrame, text=evoName, width=120, command=lambda s=species:self.evolve_into(s))
            button.pack(expand=False, fill="y", padx=20, pady=(5,20), anchor="w")
            if evoLevel > self.__pokemon.get_level():
                button.configure(state="disabled")
    
    def evolve_into(self, evoSpecies):
        evolution = self.__m.evolve(self.__pokemon, evoSpecies)
        self.__app.update_pokemon_list()
        self.__app.update_pokemon_info(evolution)
        self.destroy()          
     
class TeamExporter(ctk.CTkToplevel):
    def __init__(self, app):
        super().__init__(app)
        self.transient(app)
        self.grab_set()
        
        self.__app = app
        self.__m = app.get_manager()
        
        self.title("Pokémon Manager")
        self.geometry("500x500")
        self.minsize(400, 400)
        self.build_widgets()
        
    def build_widgets(self):       
        self.__tabs = {}
        self.__tabs["selection"] = ctk.CTkFrame(self, fg_color="transparent")
        self.__tabs["copy"] = ctk.CTkFrame(self, fg_color="transparent")
        
        self.__tabs["selection"].pack(expand=True, fill="both")
        
        titleFont = ctk.CTkFont(size=16, weight="bold")
        
        # First page
        self.__selectionLabel = ctk.CTkLabel(self.__tabs["selection"], text="Select up to six party members", font=titleFont)
        self.__selectionLabel.pack(expand=False, fill="both", padx=20, pady=5)
        
        self.__selectionFrame = ctk.CTkFrame(self.__tabs["selection"], corner_radius=0)
        self.__selectionFrame.pack(expand=True, fill="both")
        
        self.__list = PokemonList(self.__selectionFrame, self.__app)
        self.__list.configure_function()
        self.__list.pack(expand=True, fill="both", padx=20, pady=(20,0))
        
        self.__warning = ctk.CTkLabel(self.__selectionFrame, text="", anchor="w", text_color="red")
        self.__warning.pack(expand=False, fill="both", padx=20, pady=5)
        
        self.__nextButton = ctk.CTkButton(self.__selectionFrame, text="Next", command=self.check_team_members)
        self.__nextButton.pack(expand=False, fill="both", padx=20, pady=(0,20))
                
        # Second page
        self.__copyLabel = ctk.CTkLabel(self.__tabs["copy"], text="Team export (pokémon showdown format)", font=titleFont)
        self.__copyLabel.pack(expand=False, fill="both", padx=20, pady=5)
        
        self.__copyFrame = ctk.CTkFrame(self.__tabs["copy"], corner_radius=0)
        self.__copyFrame.pack(expand=True, fill="both")
        
        self.__textbox = ctk.CTkTextbox(self.__copyFrame)
        self.__textbox.pack(expand=True, fill="both", padx=20, pady=(20,0))
        
        self.__info = ctk.CTkLabel(self.__copyFrame, text="", anchor="w")
        self.__info.pack(expand=False, fill="both", padx=20, pady=5)
        
        self.__copyButton = ctk.CTkButton(self.__copyFrame, text="Copy", command=self.copy)
        self.__copyButton.pack(expand=False, fill="both", padx=20, pady=(0,20))
    
    def create_string(self):
        string = ""
        pokemonList = [p for p in self.__m.get_pokemon() if p.get_name() in self.__list.get()]
        
        for pokemon in pokemonList:
            # Name
            string += pokemon.get_name()
            
            # Gender
            if pokemon.get_gender() == "M":
                string += " (M)"
            if pokemon.get_gender() == "F":
                string += " (F)"
            
            # Item
            if pokemon.get_held_item() is not None:
                string += " @ " + pokemon.get_held_item().get_name()
            
            # Ability
            string += "\nAbility: " + pokemon.get_ability().get_name()
            
            # Level
            string += "\nLevel: " + str(pokemon.get_level())
            
            # Shiny
            if pokemon.get_shiny == True:
                string += "\nShiny: Yes"
            
            # Stats
            EV, IV =  pokemon.get_stats()
            
            string += "\nEVs: "
            for stat in EV:
                string += str(EV[stat]) + " " + stat + " / "
            
            string += "\n" + pokemon.get_nature()[0] + " nature"
            
            string += "\nIVs: "
            for stat in IV:
                string += str(IV[stat]) + " " + stat + " / "
            
            # Moves
            for move in pokemon.get_moves():
                if move is not None:
                    string += "\n- " + move.get_name()
            
            string += "\n\n"
            
        return string
    
    def check_team_members(self):
        if self.__list.get() is None:
            self.__warning.configure(text="Select at least one pokémon.")
        elif len(self.__list.get()) > 6:
            self.__warning.configure(text="A team can have a maximum of six pokémon. Select less pokémon to proceed.")
        else:
            self.next_tab()
    
    def next_tab(self):
        self.__tabs["selection"].pack_forget()
        self.__tabs["copy"].pack(expand=True, fill="both")
        
        self.__string = self.create_string()
        self.__textbox.insert("insert", self.__string)
        self.__textbox.configure(state="disabled")
    
    def copy(self):
        self.__app.clipboard_clear()
        self.__app.clipboard_append(self.__string)
        
        self.__info.configure(text="Team copied to clipboard.")
        
        self.__app.after(500, self.destroy)
        
class OptionsMenu(ctk.CTkToplevel):
    def __init__(self, app):
        super().__init__(app)
        self.transient(app)
        self.grab_set()
        
        self.__app = app
        self.__m = app.get_manager()
        
        self.title("Pokémon Manager")
        self.geometry("600x415")
        self.minsize(600, 415)
        self.build_widgets()
        
    def build_widgets(self):
        cheats = self.__m.get_cheats()
        adventurePreferences = self.__m.get_adventure_preferences()
        
        # Top frame
        self.__topFrame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.__topFrame.pack(expand=False, fill="both")
        self.__topFrame.grid_columnconfigure(0, weight=1)
        
        titleFont = ctk.CTkFont(size=24, weight="bold")
        self.__title = ctk.CTkLabel(self.__topFrame, text="Settings", font=titleFont, anchor="w")
        self.__title.grid(row=0, column=0, padx=20, pady=10, sticky="nsew")
        
        self.__emptyButton = ctk.CTkButton(self.__topFrame, text="Empty bag",
                                          width=80, corner_radius=0, fg_color="gray10", command=self.empty_bag)
        self.__emptyButton.grid(row=0, column=2, sticky="nsew")
        
        self.__wipeButton = ctk.CTkButton(self.__topFrame, text="Wipe save",
                                          width=80, corner_radius=0, fg_color="gray10", command=self.wipe_save)
        self.__wipeButton.grid(row=0, column=3, sticky="nsew")
        
        self.__resetButton = ctk.CTkButton(self.__topFrame, text="Default\nsettings",
                                           width=80, corner_radius=0, fg_color="gray10", command=self.default_settings)
        self.__resetButton.grid(row=0, column=4, sticky="nsew")
        
        self.__saveButton = ctk.CTkButton(self.__topFrame, text="Save changes",
                                          width=100, corner_radius=0, command=self.save_changes)
        self.__saveButton.grid(row=0, column=5, sticky="nsew")
        
        # Bottom frame
        self.__bottomFrame = ctk.CTkFrame(self, corner_radius=0)
        self.__bottomFrame.pack(expand=True, fill="both")
        self.__bottomFrame.grid_columnconfigure([0,1], weight=1)
        
        frameTitleFont = ctk.CTkFont(weight="bold")
        
        # --- Generation
        self.__generationFrame = ctk.CTkFrame(self.__bottomFrame, border_width=2)
        self.__generationFrame.grid(row=0, column=0, columnspan=2, sticky="nsew", padx=20, pady=(20, 0))
        
        self.__newGen = self.__m.get_gen()
        
        self.__genLabel = ctk.CTkLabel(self.__generationFrame, text="Generation:", anchor="w", font=frameTitleFont)
        self.__genLabel.grid(row=0, column=0, sticky="nsew", padx=10, pady=(5,0))
        
        generations = ["Gen 3", "Gen 4", "Gen 5", "Gen 6", "Gen 7", "Gen 8", "Gen 9"]
        self.__genString = ctk.StringVar(value=f"Gen {self.__newGen}")
        self.__genString.trace("w", self.on_gen_combobox_selected)
        self.__genDropdown = ctk.CTkOptionMenu(self.__generationFrame, values=generations, variable=self.__genString)
        self.__genDropdown.grid(row=1, column=0, padx=20, pady=(10,20))
        
        self.__warningLabel = ctk.CTkLabel(self.__generationFrame, text="", text_color="red", anchor="w")
        self.__warningLabel.grid(row=1, column=1, padx=0, pady=(10,20), sticky="nsew")
        
        # --- Cheats
        self.__cheatsFrame = ctk.CTkFrame(self.__bottomFrame, border_width=2)
        self.__cheatsFrame.grid(row=1, column=0, sticky="nsew", padx=20, pady=20)
        
        self.__cheatsLabel = ctk.CTkLabel(self.__cheatsFrame, text="Pokémon:", anchor="w", font=frameTitleFont)
        self.__cheatsLabel.grid(row=0, column=0, sticky="nsew", padx=10, pady=(5,0))
        
        self.__shinyGen = ctk.BooleanVar()
        self.__ivChange = ctk.BooleanVar()
        self.__natureChange = ctk.BooleanVar()
        self.__abilityChange = ctk.BooleanVar()
        
        self.__shinyGen.set(cheats["Shiny"])
        self.__ivChange.set(cheats["IV"])
        self.__natureChange.set(cheats["Nature"])
        self.__abilityChange.set(cheats["Ability"])
        
        self.__shinySwitch = ctk.CTkSwitch(self.__cheatsFrame, variable=self.__shinyGen, text="Shiny pokémon.")
        self.__ivSwitch = ctk.CTkSwitch(self.__cheatsFrame, variable=self.__ivChange, text="Perfect IVs, modify IVs.")
        self.__natureSwitch = ctk.CTkSwitch(self.__cheatsFrame, variable=self.__natureChange, text="Modify natures.")
        self.__abilitySwitch = ctk.CTkSwitch(self.__cheatsFrame, variable=self.__abilityChange, text="Modify abilities.")
        
        self.__shinySwitch.grid(row=1, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__ivSwitch.grid(row=2, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__natureSwitch.grid(row=3, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__abilitySwitch.grid(row=4, column=0, sticky="nsew", padx=20, pady=(10,20))
        
        # --- Adventure
        self.__adventureFrame = ctk.CTkFrame(self.__bottomFrame, border_width=2)
        self.__adventureFrame.grid(row=1, column=1, sticky="nsew", padx=20, pady=20)
        
        self.__autoGenerate = ctk.BooleanVar()
        self.__autoUnlock = ctk.BooleanVar()
        self.__autoLevel = ctk.BooleanVar()
        self.__imageSize = ctk.IntVar()
        
        self.__autoGenerate.set(adventurePreferences["Generate"])
        self.__autoUnlock.set(adventurePreferences["Unlock"])
        self.__autoLevel.set(adventurePreferences["Level"])
        self.__imageSize.set(adventurePreferences["Size"])
        
        self.__generateSwitch = ctk.CTkSwitch(self.__adventureFrame, variable=self.__autoGenerate, text="Generate pokémon upon catching.")
        self.__unlockSwitch = ctk.CTkSwitch(self.__adventureFrame, variable=self.__autoUnlock, text="Automatically unlock items and TMs.")
        self.__levelSwitch = ctk.CTkSwitch(self.__adventureFrame, variable=self.__autoLevel, text="Automatically update level cap.")
        self.__sizeSlider = ctk.CTkSlider(self.__adventureFrame, variable=self.__imageSize, from_=200, to=400, number_of_steps=4)
        self.__sizeLabel = ctk.CTkLabel(self.__adventureFrame, text="Image size:", anchor="w")
        
        self.__generateSwitch.grid(row=1, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__unlockSwitch.grid(row=2, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__levelSwitch.grid(row=3, column=0, sticky="nsew", padx=20, pady=(10,0))
        self.__sizeLabel.grid(row=4, column=0, sticky="nsew", padx=20, pady=(10,5))
        self.__sizeSlider.grid(row=5, column=0, sticky="nsw", padx=20, pady=(0,20))
        
        self.__adventureLabel = ctk.CTkLabel(self.__adventureFrame, text="Adventure:", anchor="w", font=frameTitleFont)
        self.__adventureLabel.grid(row=0, column=0, sticky="nsew", padx=10, pady=(5,0))
        
    def on_gen_combobox_selected(self, *kwargs):
        self.__newGen = int(self.__genString.get().split(" ")[1])
        if self.__newGen != self.__m.get_gen():
            self.__warningLabel.configure(text="If you change the generation, unsaved progress will be lost.")
        else:
            self.__warningLabel.configure(text="")
        
    def default_settings(self):
        self.__genString.set("Gen 9")
        
        self.__shinyGen.set(False)
        self.__ivChange.set(False)
        self.__natureChange.set(False)
        self.__abilityChange.set(True)
        
        self.__autoGenerate.set(True)
        self.__autoUnlock.set(True)
        self.__autoLevel.set(True)
        self.__imageSize.set(300)
        
    def save_changes(self):
        self.__m.set_cheats({"Shiny": self.__shinyGen.get(), "IV": self.__ivChange.get(),
                             "Nature": self.__natureChange.get(), "Ability": self.__abilityChange.get()})
        
        oldImageSize = self.__m.get_adventure_preferences()["Size"]
        self.__m.set_adventure_preferences({"Generate": self.__autoGenerate.get(), "Unlock": self.__autoUnlock.get(),
                                            "Level": self.__autoLevel.get(), "Size": self.__imageSize.get()})
        
        if oldImageSize != self.__imageSize.get():
            self.__app.get_adventure_viewer().update()
        
        if self.__m.get_gen() != self.__newGen:
            self.__m.set_gen(self.__newGen)
            self.wipe_save()
        
        self.__app.update_pokemon_info()
        self.destroy()
    
    def empty_bag(self):
        self.__m.empty_bag()
        self.__app.update_pokemon_info()
        self.destroy()
    
    def wipe_save(self):
        self.__m.wipe_save()
        self.__app.update_pokemon_list()
        self.__app.get_pokemon_information().hide_widgets()
        self.__app.get_adventure_viewer().update()
        self.destroy()
        

###############################################################################
"""
        ADVENTURE MODE
"""
###############################################################################
    
class AdventureViewer(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app)
        self.__app = app
        self.__m = app.get_manager()
        
        self.__currentStage = None
        
        self.build_widgets()
        self.update()
        
    def build_widgets(self):
        # Top frame
        self.__topFrame = ctk.CTkFrame(self, fg_color="gray10", corner_radius=0)
        self.__topFrame.pack(expand=False, fill="both")
        self.__topFrame.grid_columnconfigure(0, weight=1)
        
        titleFont = ctk.CTkFont(size=20, weight="bold")
        self.__topLabel = ctk.CTkLabel(self.__topFrame, text="Adventure mode", font=titleFont, anchor="w")
        self.__topLabel.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        self.__loadButton = ctk.CTkButton(self.__topFrame, text="Load new", corner_radius=0,
        width=70, fg_color="gray10", command=self.load_adventure)
        self.__loadButton.grid(row=0, column=1, sticky="nsew")
        
        self.__loadButton = ctk.CTkButton(self.__topFrame, text="Set step", corner_radius=0,
        width=70, fg_color="gray10", command=self.set_step)
        self.__loadButton.grid(row=0, column=2, sticky="nsew")
        
        self.__settingsButton = ctk.CTkButton(self.__topFrame, text="Settings", corner_radius=0,
        width=70, fg_color="gray10", command=self.__app.options_window)
        self.__settingsButton.grid(row=0, column=3, sticky="nsew")
        
        self.__mainButton = ctk.CTkButton(self.__topFrame, text="Manager", corner_radius=0,
        width=100, command=self.__app.show_main)
        self.__mainButton.grid(row=0, column=4, sticky="nsew")
        
        self.__tabs = {}
        self.__tabs["placeholder"] = ctk.CTkFrame(self)
        self.__tabs["main"] = ctk.CTkFrame(self)
        
        # Placeholder frame
        self.__placeholderLabel = ctk.CTkLabel(self.__tabs["placeholder"], text="No adventure loaded. Select an adventure to proceed.")
        self.__placeholderLabel.pack(expand=True, fill="both")
        
        # Initialize these so that they can be destroyed later
        self.__scrollingFrame = ctk.CTkScrollableFrame(self.__tabs["main"])
        self.__stageChange = ctk.CTkFrame(self.__scrollingFrame, border_width=2)
        self.__stepFrames = {}
    
    def update(self):
        if self.__m.get_adventure() is None:
            self.__tabs["main"].pack_forget()
            self.__tabs["placeholder"].pack(expand=True, fill="both")
            
            self.__topLabel.configure(text="Adventure mode")
        
        else:
            self.__tabs["placeholder"].pack_forget()
            self.__tabs["main"].pack(expand=True, fill="both")
            
            adventure = self.__m.get_adventure()
            self.__topLabel.configure(text=adventure.get_title())
            self.__currentStage = adventure.get_current().get_stage()
            self.build_items()
            
    def build_items(self):
        # Destroy old frames:
        for stepFrame in self.__stepFrames.values():
            stepFrame.destroy()
        self.__stageChange.destroy()
        
        self.__scrollingFrame.pack_forget()
        self.__scrollingFrame.destroy()
        
        self.__scrollingFrame = ctk.CTkScrollableFrame(self.__tabs["main"])
        self.__stepFrames = {}
        
        # Create new frames:
        adventure = self.__m.get_adventure()
        for step in adventure.get_steps().values():
            if step.get_stage() == self.__currentStage:
                self.__stepFrames[step.get_name()] = AdventureStepFrame(self.__scrollingFrame, self.__app, step)
                
                # Add padding or not depending on if the step is a continuation
                if step.get_continuation() == False:
                    pady=(30,0)
                else:
                    pady=0
                
                self.__stepFrames[step.get_name()].pack(expand=False, fill="both", padx=10, pady=pady)
        
        # Frame to change stage:
        self.__stageChange = ctk.CTkFrame(self.__scrollingFrame, border_width=2, fg_color="gray16")
        self.__stageChange.pack(expand=True, fill="both", padx=10, pady=20)
        
        self.__NextButton = ctk.CTkButton(self.__stageChange, text="Next stage",
        command=lambda:self.change_stage(1), width=120)
        self.__PreviousButton = ctk.CTkButton(self.__stageChange, text="Previous stage",
        command=lambda:self.change_stage(-1), width=120)
        
        stageFont = ctk.CTkFont(size=18)
        self.__stageLabel = ctk.CTkLabel(self.__stageChange, text=self.__currentStage, font=stageFont)
        
        self.__stageChange.grid_columnconfigure(1, weight=1)
        self.__NextButton.grid(row=0, column=2, padx=10, pady=10)
        self.__PreviousButton.grid(row=0, column=0, padx=10, pady=10)
        self.__stageLabel.grid(row=0, column=1, padx=10, pady=10)
                
        self.__scrollingFrame.pack(expand=True, fill="both")
        
        # Update buttons
        self.update_buttons()
        
    def change_stage(self, value):
        stageList = self.__m.get_adventure().get_stages()
        currentIndex = stageList.index(self.__currentStage)
        self.__currentStage = stageList[currentIndex + value]
        
        self.build_items()
    
    def load_adventure(self):
        fileName = filedialog.askdirectory(initialdir="adventures", title="Select adventure folder")
        if fileName:
            self.__m.load_adventure(fileName)
            self.update()
            self.__app.update_pokemon_list()
            self.__app.reset_pokemon_info()
        else:
            log.warning('No file selected.')
    
    def update_buttons(self):
        # Enable / disable option buttons
        currentStep = self.__m.get_adventure().get_current().get_name()
        
        for stepName in self.__stepFrames.keys():
            if stepName == currentStep:
                self.__stepFrames[stepName].set_button_state("normal")
            elif stepName:
                self.__stepFrames[stepName].set_button_state("disabled")
                
        # Enable / disable stage-changing buttons
        stageList = self.__m.get_adventure().get_stages()
        stageIndex = stageList.index(self.__currentStage)
        
        if stageIndex == 0:
            self.__PreviousButton.configure(state="disabled")
        else:
            self.__PreviousButton.configure(state="normal")
        
        if stageIndex + 1 == len(stageList):
            self.__NextButton.configure(state="disabled")
        else:
            self.__NextButton.configure(state="normal")
    
    def set_step(self):
        if self.__m.get_adventure() is not None:
            self.__stepSelector = AdventureStepSelector(self.__app)
        else:
            log.warning('Cannot change step. No adventure loaded.')

class AdventureStepFrame(ctk.CTkFrame):
    def __init__(self, parent, app, step):
        super().__init__(parent, fg_color="gray16", corner_radius=0)
        self.__app = app
        self.__m = self.__app.get_manager()
        self.__step = step
        
        self.__bigFont = ctk.CTkFont(size=24, weight="bold")
        self.build_widgets()
        self.build_options()
        
    def build_widgets(self):
        
        # Title only appears when step is not the continuation of a previous step
        if self.__step.get_continuation() == False:
            title = self.__step.get_name()
            self.__title = ctk.CTkLabel(self, text=title, font=self.__bigFont, anchor="w")
            self.__title.pack(expand=True, fill="both", padx=10, pady=10)
        
        self.__topFrame = ctk.CTkFrame(self, fg_color="transparent")
        self.__topFrame.pack(expand=False, fill="x")
        self.__topFrame.grid_columnconfigure(1, weight=1)
        self.__topFrame.grid_rowconfigure(0, weight=1)
        
        self.__imageFrame = ctk.CTkFrame(self.__topFrame, fg_color="transparent")
        imagePath = self.__step.get_image()
        if imagePath != "":
            topFrameHeight = self.__m.get_adventure_preferences()["Size"]
            try:
                adventurePath = self.__m.get_adventure().get_path()
                self.__image = ctk.CTkImage(Image.open(f"{adventurePath}/images/{imagePath}"), size=(topFrameHeight, topFrameHeight))
                self.__imageLabel = ctk.CTkLabel(self.__imageFrame, text="", image=self.__image)
                self.__imageLabel.pack(expand=True, fill="both")
                self.__imageFrame.pack(side="right", expand=False, fill="both", padx=(0,10))
            
            except FileNotFoundError:
                log.warning('Image for step %s not found.', title)
        else:
            topFrameHeight = 200
        
        self.__textBox = ctk.CTkTextbox(self.__topFrame, wrap="word", height=topFrameHeight)
        text = self.__step.get_text()
        if text != "":
            self.__textBox.insert("insert", text)
            self.__textBox.configure(state="disabled")
            self.__textBox.pack(side="right", expand=True, fill="both", padx=10)
        
        # Middle frame only appears if there are pokémon to catch in step
        unique_pokemon = []
        for option in self.__step.get_options().values():
            if "pokemon" in option.get_unlocks():
                for name in option.get_unlocks()["pokemon"]:
                    if name not in unique_pokemon:
                        unique_pokemon.append(name)
        
        if unique_pokemon != []:
            self.__middleFrame = ctk.CTkFrame(self, fg_color="transparent")
            self.__middleFrame.pack(expand=False, fill="both")
            
            monDict = self.__m.all_pokemon_names()
            images = []
            for name in unique_pokemon:
                try:
                    images.append(ctk.CTkImage(Image.open(f"assets/sprites/normal/{monDict[name]}.png"), size=(140,140)))
                except KeyError:
                    images.append(ctk.CTkImage(Image.open("assets/sprites/no_image.png"), size=(140,140)))
            
            for image in images:
                label = ctk.CTkLabel(self.__middleFrame, text="", image=image)
                label.pack(side="left")
        
        self.__bottomFrame = ctk.CTkFrame(self, fg_color="transparent")
        self.__bottomFrame.pack(expand=False, fill="both", pady=10)
        
    def build_options(self):
        self.__optionFrames = {}
        for index, (optionName, option) in enumerate(self.__step.get_options().items()):
            self.__bottomFrame.grid_columnconfigure(index, weight=1, uniform=True)
            self.__optionFrames[optionName] = AdventureOptionFrame(self.__bottomFrame, self.__app, option)
            self.__optionFrames[optionName].grid(row=0, column=index, padx=10, sticky="nsew")
            
    def set_button_state(self, state):
        if state == "normal":
            color = "#1f538d"
        else:
            color = "gray21"
        
        for optionFrame in self.__optionFrames.values():
            optionFrame.get_button().configure(state=state, fg_color=color)
            
class AdventureOptionFrame(ctk.CTkFrame):
    def __init__(self, parent, app, option):
        super().__init__(parent, border_width=2)
        self.__app = app
        self.__m = self.__app.get_manager()
        self.__option = option
        
        self.build_widgets()
        
    def build_widgets(self):
        unlockDict = self.__option.get_unlocks()
        paddingNecessary = True
        
        # Level cap
        if "new levelcap" in unlockDict:
            text = "New level cap: " + str(unlockDict["new levelcap"]) + "\n"
            ctk.CTkLabel(self, text=text, anchor="w").pack(expand=False, fill="both", padx=10, pady=(10,0))
            paddingNecessary = False
            
        # Items
        if "items" in unlockDict:
            ctk.CTkLabel(self, text="Unlock the following items:", anchor="w").pack(expand=False, fill="both", padx=10, pady=(5,0))
            text = ""
            for item in unlockDict["items"]:
                text += f"- {item}\n"
            ctk.CTkLabel(self, text=text, anchor="w", justify="left").pack(expand=False, fill="both", padx=10)
            paddingNecessary = False
            
        # TMs
        if "tms" in unlockDict:
            ctk.CTkLabel(self, text="Unlock the following TMs:", anchor="w").pack(expand=False, fill="both", padx=10, pady=(5,0))
            text = ""
            for tm in unlockDict["tms"]:
                text += f"- {tm}\n"
            ctk.CTkLabel(self, text=text, anchor="w", justify="left").pack(expand=False, fill="both", padx=10)
            paddingNecessary = False
            
        # Pokémon
        if "pokemon" in unlockDict:
            if len(unlockDict["pokemon"]) == 1:
                text = "Catch a: " + unlockDict["pokemon"][0] + "\n"
                ctk.CTkLabel(self, text=text, anchor="w").pack(expand=False, fill="both", padx=10, pady=(10,0))
                
            else:
                ctk.CTkLabel(self, text="Catch a random pokémon between:", anchor="w").pack(expand=False, fill="both", padx=10, pady=(5,0))
                text = ""
                for mon in unlockDict["pokemon"]:
                    text += f"- {mon}\n"
                ctk.CTkLabel(self, text=text, anchor="w", justify="left").pack(expand=False, fill="both", padx=10)
            paddingNecessary = False
                
        self.__button = ctk.CTkButton(self, text=self.__option.get_name(), width=120)
        self.__button.configure(command=self.unlock_option)
        
        if paddingNecessary == True:
            self.__button.pack(side="bottom", padx=10, pady=10)
        else:
            self.__button.pack(side="bottom", padx=10, pady=(0,10))
    
    def unlock_option(self):
        unlockDict = self.__option.get_unlocks()
        adventurePreferences = self.__m.get_adventure_preferences()
        
        # Level cap
        if "new levelcap" in unlockDict and adventurePreferences["Level"] == True:
            self.__m.set_levelcap(unlockDict["new levelcap"])
        
        # Items
        if "items" in unlockDict and adventurePreferences["Unlock"] == True:
            itemsDict = self.__m.all_items()
            for name in unlockDict["items"]:
                if name in itemsDict:
                    itemsDict[name].set_unlocked(True)
                else:
                    log.warning('Item named %s does not exist.', name)
        
        # TMs
        if "tms" in unlockDict and adventurePreferences["Unlock"] == True:
            tmsDict = self.__m.all_tms()
            for name in unlockDict["tms"]:
                if name in tmsDict:
                    tmsDict[name].set_unlocked(True)
                else:
                    log.warning('TM named %s does not exist.', name)
        
        # Pokémon
        if "pokemon" in unlockDict and adventurePreferences["Generate"] == True:
            monDict = self.__m.all_pokemon_names()
            
            monList = []
            for monName in unlockDict["pokemon"]:
                if monName in monDict:
                    monList.append(monName)
                else:
                    log.warning('Pokémon named %s does not exist.', monName)
            
            if monList != []:
                chosenMon = random.choice(monList)
                self.__m.new_pokemon(monDict[chosenMon])
        
        self.__m.update_pokemon_movepools()
        self.__app.update_pokemon_list()
        self.__app.update_pokemon_info()
        self.next_step()
    
    def next_step(self):
        self.__m.get_adventure().next_step()
        adventureViewer = self.__app.get_adventure_viewer()
        adventureViewer.update_buttons()
                
    def get_button(self):
        return self.__button
        
        
###############################################################################
"""
        POKEMON INFORMATION
"""
###############################################################################

class PokemonInformation(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.__app = app
        self.__m = self.__app.get_manager()
        
        self.__smallFont = ctk.CTkFont(size=10)
        self.__mediumFont = ctk.CTkFont(size=16)
        self.__bigFont = ctk.CTkFont(size=30, weight="bold")
        self.__pokemonSelected = False
        
        self.build_widgets()
    
    def build_widgets(self):
        self.__placeholder = ctk.CTkLabel(self, text="Select a pokémon.")
        self.__placeholder.pack(expand=True, fill="both")
        
        # Make tabs
        self.__tabView = ctk.CTkTabview(self)
        
        self.__tabs = {}
        self.__tabs["general"] = self.__tabView.add("General")
        self.__tabs["moves"] = self.__tabView.add("Moves")
        self.__tabs["stats"] = self.__tabView.add("Stats")
        
        # Build general widgets
        
        # --- Top frame
        self.__nameFrame = ctk.CTkFrame(self.__tabs["general"])
        self.__nameFrame.pack(expand=False, fill="both", padx=10, pady=10)
        
        self.__pokemonName = ctk.CTkLabel(self.__nameFrame, text="", font=self.__bigFont)
        self.__pokemonName.pack(side="left", padx=20)
        
        self.__genderIcon = ctk.CTkImage(Image.open("assets/genders/genderless.png"), size=(30, 30))
        self.__genderLabel = ctk.CTkLabel(self.__nameFrame, text="", image=self.__genderIcon)
        self.__genderLabel.pack(side="left", padx=(0,20))
        
        self.__typeIcon1 = ctk.CTkImage(Image.open("assets/types/no_type.png"), size=(60, 60))
        self.__typeIcon2 = ctk.CTkImage(Image.open("assets/types/no_type.png"), size=(60, 60))
        self.__typeLabel1 = ctk.CTkLabel(self.__nameFrame, text="", image=self.__typeIcon1)
        self.__typeLabel2 = ctk.CTkLabel(self.__nameFrame, text="", image=self.__typeIcon2)
        self.__typeLabel2.pack(side="right", padx=(10, 20), pady=10)
        self.__typeLabel1.pack(side="right", pady=10)
        
        # --- Bottom frame
        self.__bottomFrame = self.__nameFrame = ctk.CTkFrame(self.__tabs["general"], corner_radius=0, fg_color="transparent")
        self.__bottomFrame.pack(expand=True, fill="both", padx=10, pady=(0,10))
        self.__bottomFrame.grid_rowconfigure(0, weight=1)
        self.__bottomFrame.grid_columnconfigure(0, weight=1)
        
        # --- --- Left frame
        self.__leftFrame = ctk.CTkFrame(self.__bottomFrame, corner_radius=0, fg_color="transparent")
        self.__leftFrame.grid(row=0, column=0, sticky="nsew")
        
        # --- --- --- Level & level cap
        self.__levelFrame = ctk.CTkFrame(self.__leftFrame)
        self.__levelFrame.pack(expand=False, fill="both", padx=(0,10), pady=(0,10))
        
        ctk.CTkLabel(self.__levelFrame, text="Lv.", font=self.__mediumFont).pack(side="left", padx=20, pady=20)
        self.__levelString = ctk.StringVar()
        self.__levelString.trace("w", self.on_entry_changed)
        self.__levelEntry = ctk.CTkEntry(self.__levelFrame, textvariable=self.__levelString, width=80)
        self.__levelEntry.pack(side="left", pady=20)
        
        self.__synched = ctk.BooleanVar()
        self.__synched.trace("w", self.on_synchronizer_toggled)
        self.__synchronizer = ctk.CTkSwitch(self.__levelFrame, text="Sync with levelcap", font=self.__smallFont, variable=self.__synched)
        self.__synchronizer.pack(side="left", padx=20, pady=20)
        
        # --- --- --- Item & ability
        self.__abilityInformationFrame = GeneralInformation(self.__leftFrame, self.__m, "ability")
        self.__abilityInformationFrame.pack(expand=True, fill="both", padx=(0,10), pady=(0,10))
        self.__itemInformationFrame = GeneralInformation(self.__leftFrame, self.__m, "item")
        self.__itemInformationFrame.pack(expand=True, fill="both", padx=(0,10))
        
        # --- --- Right frame
        self.__rightFrame = ctk.CTkFrame(self.__bottomFrame, corner_radius=0, fg_color="transparent")
        self.__rightFrame.grid(row=0, column=1, sticky="nsew")
        
        # --- --- --- Image
        self.__pokemonImage = ctk.CTkImage(Image.open("assets/sprites/no_image.png"), size=(200,200))
        self.__imageFrame = ctk.CTkFrame(self.__rightFrame)
        self.__imageFrame.pack(expand=True, fill="both", side="top", pady=(0,10))
        self.__imageLabel = ctk.CTkLabel(self.__imageFrame, text="", image=self.__pokemonImage)
        self.__imageLabel.pack(expand=True, fill="both", padx=10, pady=10)
        
        # --- --- --- Evolution
        self.__evolutionButton = ctk.CTkButton(self.__rightFrame, text="Evolution")
        self.__evolutionButton.pack(side="top", expand=False, fill="both", pady=(0,5))
        
        self.__evolutionFrame = ctk.CTkFrame(self.__rightFrame)
        self.__evolutionFrame.pack(side="top", expand=False, fill="both", pady=(0,10))
        
        self.__evolutionInformation = ctk.CTkLabel(self.__evolutionFrame, text="", wraplength=200, font=self.__smallFont)
        self.__evolutionInformation.pack(expand=True, fill="both", padx=5, pady=5)
        
        # --- --- --- Delete button
        self.__deleteButton = ctk.CTkButton(self.__rightFrame, text="Delete pokémon", command=self.delete_pokemon, fg_color="gray28")
        self.__deleteButton.pack(side="top", expand=False, fill="both")
        
        # Build move widgets
        self.__moveInformationFrames = []
        for slot in range(4):
            self.__moveInformationFrames.append(MoveInformation(self.__tabs["moves"], slot))
            self.__moveInformationFrames[slot].pack(side="top", expand=True, fill="both", padx=5, pady=5)
        
        # Build stat widgets
        self.__statTopFrame = ctk.CTkFrame(self.__tabs["stats"])
        self.__statTopFrame.pack(side="top", expand=False, fill="both", padx=10, pady=10)
        
        self.__natureLabel = ctk.CTkLabel(self.__statTopFrame, text="Nature", width=50, font=ctk.CTkFont(size=16, weight="bold"))
        self.__natureLabel.pack(side="left", padx=20, pady=15)
        
        natures = list(self.__m.get_natures().keys())
        self.__natureString = ctk.StringVar()
        self.__natureString.trace("w", self.on_nature_changed)
        self.__natureDropdown = ctk.CTkOptionMenu(self.__statTopFrame, variable=self.__natureString, values=natures)
        self.__natureDropdown.pack(side="left", pady=15)
        
        self.__saveSpreadButton = ctk.CTkButton(self.__statTopFrame, text="Save as default EV spread", command=self.save_default_spread, fg_color="gray28")
        self.__saveSpreadButton.pack(side="right", fill="y", padx=20, pady=15)
        
        self.__saveSpreadLabel = ctk.CTkLabel(self.__statTopFrame, text="", anchor="e")
        self.__saveSpreadLabel.pack(side="right")
        
        self.__statInformationFrames = []
        self.__EVTotal = ctk.IntVar()
        for stat in ["HP", "Atk", "Def", "SpA", "SpD", "Spe"]:
            self.__statInformationFrames.append(StatInformation(self.__tabs["stats"], self, stat))
            self.__statInformationFrames[-1].pack(side="top", expand=True, fill="both", padx=10, pady=5)
    
    def hide_widgets(self):
        self.__tabView.pack_forget()
        self.__placeholder.pack(expand=True, fill="both")
        self.__pokemonSelected = False
        
    def show_widgets(self):
        self.__placeholder.pack_forget()
        self.__tabView.pack(expand=True, fill="both")
        self.__pokemonSelected = True
    
    def get_EV_total(self):
        total = 0
        for stat in self.__statInformationFrames:
            total += stat.get()
        return total
    
    def update(self, pokemon):       
        if pokemon is not None:
            if self.__pokemonSelected == False:
                self.show_widgets()
            
            # If the update happened because of a pokémon change:
            
            self.__pokemon = pokemon
            self.focus_set()    # De-select everything
            
            # Ability
            self.__abilityInformationFrame.set_pokemon(self.__pokemon)
            self.__abilityInformationFrame.update_information()
            
            # Stats
            for stat in self.__statInformationFrames:
                stat.set_pokemon(self.__pokemon)
            
            # Everything on name bar
            self.__pokemonName.configure(text=self.__pokemon.get_name())
            types = self.__pokemon.get_types()
            if len(types) == 2:
                self.__typeIcon1.configure(dark_image=Image.open(f"assets/types/{types[0]}_icon_Sleep.png"))
                self.__typeIcon2.configure(dark_image=Image.open(f"assets/types/{types[1]}_icon_Sleep.png"))
            else:
                self.__typeIcon1.configure(dark_image=Image.open("assets/types/no_type.png"))
                self.__typeIcon2.configure(dark_image=Image.open(f"assets/types/{types[0]}_icon_Sleep.png"))
            gender = self.__pokemon.get_gender()
            if gender == "M":
                self.__genderIcon.configure(dark_image=Image.open("assets/genders/male_dark.png"))
            elif gender == "F":
                self.__genderIcon.configure(dark_image=Image.open("assets/genders/female_dark.png"))
            else:
                self.__genderIcon.configure(dark_image=Image.open("assets/genders/genderless.png"))
            
            # Image and shiny
            self.update_image()
                
            # Evolution information
            self.update_evolution_label()
            self.update_evolution_command()
            
            # Nature
            self.__natureString.set(self.__pokemon.get_nature()[0])
                       
        if self.__pokemonSelected == True:
            # Here, things that are updated even without changing pokémon:
            
            # Level
            self.__levelcap = self.__m.get_levelcap()
            self.__levelString.set(str(self.__pokemon.get_level()))
            self.__synched.set(self.__pokemon.get_synched())
             
            # Item
            self.__itemInformationFrame.set_pokemon(self.__pokemon)
            self.__itemInformationFrame.update_information()
            
            # Ability
            if self.__m.get_cheats()["Ability"] == True:
                self.__abilityInformationFrame.configure_dropdown("normal")
            else:
                self.__abilityInformationFrame.configure_dropdown("disabled")
            
            # Moves
            for move in self.__moveInformationFrames:
                move.set_pokemon(self.__pokemon)
                move.update_move_information()
            
            # IVs
            for stat in self.__statInformationFrames:
                if self.__m.get_cheats()["IV"] == True:
                    stat.configure_state("normal")
                else:
                    stat.configure_state("disabled")
            
            # Nature
            if self.__m.get_cheats()["Nature"] == True:
                self.__natureDropdown.configure(state="normal")
            else:
                self.__natureDropdown.configure(state="disabled")
            
            # Evolution button
            self.update_evolution_button()
            
        
    def on_entry_changed(self, *args):
        text = self.__levelString.get()
        
        try:
            level = int(text)
            
            if level == self.__pokemon.get_level():
                return
            
            if 1 <= level <= self.__levelcap:
                self.__pokemon.set_level(level)
            elif level > self.__levelcap:
                self.__levelString.set(str(self.__levelcap))
                self.__pokemon.set_level(self.__levelcap)
            else:
                self.__levelString.set(str(1))
                self.__pokemon.set_level(1)
        
            self.update(None)
        
        except ValueError:
            # Input is not a number
            if text != "":
                self.__levelString.set(str(self.__levelcap))
    
    def on_synchronizer_toggled(self, *args):
        state = self.__synched.get()
        
        if state == True:
            self.__levelString.set(self.__levelcap)
            self.__levelEntry.configure(state="disabled")
        else:
            self.__levelEntry.configure(state="normal")
            
        if state != self.__pokemon.get_synched():
            self.__pokemon.set_synched(state)
    
    def on_nature_changed(self, *args):
        nature = self.__natureString.get()
        if nature != self.__pokemon.get_nature()[0]:
            natureDict = self.__m.get_natures()
            self.__pokemon.set_nature(nature, natureDict)
            
            for frame in self.__statInformationFrames:
                frame.update_color()
                
    def save_default_spread(self):
        EVspread = {frame.get_stat(): frame.get() for frame in self.__statInformationFrames}
        self.__m.set_default_EV_spread(EVspread)
        
        self.__saveSpreadLabel.configure(text="Saved!")
        self.__app.after(1000, lambda:self.__saveSpreadLabel.configure(text=""))
    
    def update_image(self):
        try:
            species = self.__pokemon.get_species()
            if self.__pokemon.get_shiny() == True:
                shiny = "shiny"
            else:
                shiny = "normal"
            
            if self.__pokemon.get_gender() == "F":
                try:
                    image = Image.open(f"assets/sprites/{shiny}/female/{species}.png")
                except FileNotFoundError:
                    image = Image.open(f"assets/sprites/{shiny}/{species}.png")
            else:
                image = Image.open(f"assets/sprites/{shiny}/{species}.png")
        
        except FileNotFoundError:
            image = Image.open("assets/sprites/no_image.png")
            log.warning('No image for %s.', self.__pokemon.get_name())
        
        self.__pokemonImage.configure(light_image=image, dark_image=image)
            
    def update_evolution_button(self):        
        evoDict = self.__pokemon.get_evolutions()
        if len(evoDict) == 0:
            # Check if pokémon has any evolutions
            self.__evolutionButton.configure(state="disabled")
        else:
            evoLevels = [evoInfo["level"] for evoInfo in evoDict.values()]
            # Check if pokémon can evolve
            if min(evoLevels) <= self.__pokemon.get_level():
                self.__evolutionButton.configure(state="normal")
            else:
                self.__evolutionButton.configure(state="disabled")
     
    def update_evolution_label(self):
        evoDict = self.__pokemon.get_evolutions()
        if len(evoDict) == 0:
            self.__evolutionInformation.configure(text="This pokémon does not evolve.")
        elif len(evoDict) > 1:
            self.__evolutionInformation.configure(text="This pokémon has multiple evolutions.")
        else:
            evoInfo = next(iter(evoDict.values()))
            evoLevel, evoType, evoItem, evoCondition = evoInfo["level"], evoInfo["type"], evoInfo["item"], evoInfo["condition"]
            string = f"Evolves via: {evoType}"
            if evoLevel != 0:
                string += f" at level {evoLevel}"
            if evoItem is not None:
                string += f" using the item: {evoItem}"
            if evoCondition is not None:
                string += f" {evoCondition}"
            string += "."
            self.__evolutionInformation.configure(text=string)
            
    def update_evolution_command(self):
        evoDict = self.__pokemon.get_evolutions()
        if len(evoDict) != 1:
            self.__evolutionButton.configure(command=self.open_evolution_picker)
        else:
            evoSpecies = next(iter(evoDict.keys()))
            self.__evolutionButton.configure(command=lambda:self.evolve_into(evoSpecies))
    
    def open_evolution_picker(self):
        EvolutionSelector(self.__app, self.__pokemon)
    
    def evolve_into(self, evoSpecies):
        evolution = self.__m.evolve(self.__pokemon, evoSpecies)
        self.__app.update_pokemon_list()
        self.update(evolution)
    
    def delete_pokemon(self):
        self.__m.delete_pokemon(self.__pokemon)
        self.__app.update_pokemon_list()
        self.hide_widgets()
            

class GeneralInformation(ctk.CTkFrame):
    def __init__(self, parent, manager, mode):
        super().__init__(parent, border_width=2)
        self.__mode = mode
        self.__m = manager
        self.build_widgets()
    
    def build_widgets(self):
        self.__smallFont = ctk.CTkFont(size=10)
        self.__bigFont = ctk.CTkFont(size=15)
        
        self.grid_rowconfigure([1,2], weight=1)
        self.grid_columnconfigure(1, weight=3)
        self.grid_columnconfigure(2, minsize=140)
        self.grid_columnconfigure(3, weight=5)
        
        self.__filteredList = [""]
        self.__dropdown = ctk.CTkOptionMenu(self, values=self.__filteredList, state="normal", font=self.__bigFont)
        self.__dropdown.grid(row=1, column=1, padx=20, sticky="ew")
        self.__dropdown.configure(command=self.on_select)
        
        if self.__mode == "item":
            ctk.CTkLabel(self, text="Item:", font=self.__smallFont, anchor="w").grid(row=0, column=1, sticky="sew", padx=(20,0), pady=(5,0))
            ctk.CTkLabel(self, text="Search:", font=self.__smallFont, anchor="w").grid(row=0, column=2, sticky="sew", pady=(5,0))
            self.__string = ctk.StringVar()
            self.__string.trace("w", self.on_entry_changed)
            self.__searchBar = ctk.CTkEntry(self, textvariable=self.__string, width=100)
            self.__searchBar.grid(row=1, column=2, sticky="ew", padx=(0,20))
        if self.__mode == "ability":
            ctk.CTkLabel(self, text="Ability:", font=self.__smallFont, anchor="w").grid(row=0, column=1, sticky="sew", padx=(20,0), pady=(5,0))
        
        self.__descLabel = ctk.CTkLabel(self, text="", anchor="w", justify="left")
        self.bind('<Configure>', self.update_wraplength)
        self.__descLabel.grid(row=2, column=0, columnspan=4, sticky="nsew", padx=20, pady=5)
        
    def set_pokemon(self, pokemon):
        self.__pokemon = pokemon
        if self.__mode == "ability":
            self.__objectList = self.__pokemon.get_ability_list()
            self.__list = [item.get_name() for item in self.__objectList]
            self.__filteredList = self.__list.copy()
        if self.__mode == "item":
            allItems = self.__m.all_items()
            self.__objectList = [item for item in allItems.values() if item.get_unlocked() == True]
            self.__list = [item.get_name() for item in self.__objectList]
            self.__filteredList = self.__list.copy()
            self.__filteredList.insert(0, "")
        self.__dropdown.configure(values=self.__filteredList)
      
    def on_entry_changed(self, *args):
        log.info('(General) Item entry changed.')
        searchTerm = self.__string.get().lower()
        self.__filteredList = [item for item in self.__list if searchTerm in item.lower()]
        if len(self.__filteredList) == 0:
            self.__filteredList.insert(0, "")
        elif self.__filteredList[0] != "":
            self.__filteredList.insert(0, "")
        self.__dropdown.configure(values=self.__filteredList)
    
    def on_select(self, event):
        if self.__mode == "item":
            self.__string.set("")
            self.focus_set()
        
        itemName = self.__dropdown.get()
        if itemName == "":
            newItem = None
        else:
            for item in self.__objectList:
                if item.get_name() == itemName:
                    newItem = item

        if self.__mode == "item":
            self.__pokemon.set_held_item(newItem)
        if self.__mode == "ability":
            self.__pokemon.set_ability(newItem)
        self.update_information()
            
    def configure_dropdown(self, state):
        self.__dropdown.configure(state=state)
    
    def update_information(self): 
        if self.__mode == "item":
            item = self.__pokemon.get_held_item()
        if self.__mode == "ability":
            item = self.__pokemon.get_ability()
        
        if item is not None:
            self.__dropdown.set(item.get_name())
            self.__descLabel.configure(text=item.get_description())
        else:
            self.__dropdown.set("")
            self.__descLabel.configure(text="")
            
    def update_wraplength(self, event):
        self.__descLabel.configure(wraplength=self.winfo_width() - 180)

class MoveInformation(ctk.CTkFrame):
    def __init__(self, parent, slot):
        super().__init__(parent, border_width=2)
        self.__slot = slot        
        self.build_widgets()
    
    def build_widgets(self):
        self.__smallFont = ctk.CTkFont(size=10)
        self.__bigFont = ctk.CTkFont(size=15)
        
        self.grid_rowconfigure([1,2], weight=1)
        self.grid_columnconfigure(8, minsize=25)
        self.grid_columnconfigure(1, weight=2)
        self.grid_columnconfigure(3, weight=5)
        
        self.__typeIcon = ctk.CTkImage(dark_image=Image.open("assets/types/no_type.png"), size=(60, 60))
        self.__typeLabel = ctk.CTkLabel(self, image=self.__typeIcon, text="")
        self.__typeLabel.grid(row=0, column=0, rowspan=3, sticky="nsew", padx=15, pady=10)
        
        self.__catIcon = ctk.CTkImage(dark_image=Image.open("assets/categories/no_category.png"), size=(20, 16))
        self.__catLabel = ctk.CTkLabel(self, image=self.__catIcon, text="")
        self.__catLabel.grid(row=1, column=7, sticky="ew", padx=5)
        
        self.__filteredMoveList = [""]
        self.__dropdown = ctk.CTkOptionMenu(self, values=self.__filteredMoveList, state="normal", font=self.__bigFont)
        self.__dropdown.grid(row=1, column=1, sticky="ew", padx=(5,30))
        self.__dropdown.configure(command=self.on_select)
        
        self.__string = ctk.StringVar()
        self.__string.trace("w", self.on_entry_changed)
        self.__searchBar = ctk.CTkEntry(self, textvariable=self.__string, width=100)
        self.__searchBar.grid(row=1, column=2, sticky="ew", padx=(0,10))
        
        self.__bpLabel = ctk.CTkLabel(self, text="")
        self.__bpLabel.grid(row=1, column=4, sticky="ew", padx=5)
        
        self.__accLabel = ctk.CTkLabel(self, text="")
        self.__accLabel.grid(row=1, column=5, sticky="ew", padx=5)
        
        self.__ppLabel = ctk.CTkLabel(self, text="")
        self.__ppLabel.grid(row=1, column=6, sticky="ew", padx=5)
        
        self.__descLabel = ctk.CTkLabel(self, text="", anchor="w")
        self.__descLabel.grid(row=2, column=1, columnspan=7, sticky="nsew", padx=5, pady=5)
        
        ctk.CTkLabel(self, text="Search:", font=self.__smallFont, anchor="w").grid(row=0, column=2, sticky="sew", padx=(0,10), pady=(5,0))
        ctk.CTkLabel(self, text="Power", font=self.__smallFont).grid(row=0, column=4, sticky="new", padx=5, pady=(5,0))
        ctk.CTkLabel(self, text="Accuracy", font=self.__smallFont).grid(row=0, column=5, sticky="new", padx=5, pady=(5,0))
        ctk.CTkLabel(self, text="PP", font=self.__smallFont).grid(row=0, column=6, sticky="new", padx=5, pady=(5,0))
        ctk.CTkLabel(self, text="Category", font=self.__smallFont).grid(row=0, column=7, sticky="new", padx=5, pady=(5,0))
    
    def set_pokemon(self, pokemon):
        self.__pokemon = pokemon
        self.__movepool = self.__pokemon.get_movepool()
        self.__moveList = [move.get_name() for move in self.__movepool]
        self.__moveList.insert(0, "")
        self.__filteredMoveList = self.__moveList.copy()
        self.__dropdown.configure(values=self.__filteredMoveList)
      
    def on_entry_changed(self, *args):
        log.info('(Move slot %d) Entry changed.', self.__slot)
        searchTerm = self.__string.get().lower()
        self.__filteredMoveList = [move for move in self.__moveList if searchTerm in move.lower()]
        if self.__filteredMoveList[0] != "":
            self.__filteredMoveList.insert(0, "")
        self.__dropdown.configure(values=self.__filteredMoveList)
    
    def on_select(self, event):
        self.__string.set("")
        self.focus_set()
        moveName = self.__dropdown.get()
        if moveName == "":
            newMove = None
        else:
            for move in self.__movepool:
                if move.get_name() == moveName:
                    newMove = move

        self.__pokemon.set_move(newMove, self.__slot)
        self.update_move_information()
    
    def update_move_information(self):     
        move = self.__pokemon.get_moves()[self.__slot]
        if move is not None:
            moveType, basePower, accuracy, category, pp = move.get()
            self.__typeIcon.configure(dark_image=Image.open(f"assets/types/{moveType}_icon_Sleep.png"))
            self.__catIcon.configure(dark_image=Image.open(f"assets/categories/{category}_dark.png"))
            self.__dropdown.set(move.get_name())
            self.__bpLabel.configure(text=basePower)
            self.__accLabel.configure(text=accuracy)
            self.__ppLabel.configure(text=pp)
            self.__descLabel.configure(text=move.get_description())
        else:
            self.__typeIcon.configure(dark_image=Image.open("assets/types/no_type.png"))
            self.__catIcon.configure(dark_image=Image.open("assets/categories/no_category.png"))
            self.__dropdown.set("")
            self.__bpLabel.configure(text="")
            self.__accLabel.configure(text="")
            self.__ppLabel.configure(text="")
            self.__descLabel.configure(text="Select a move.")

class StatInformation(ctk.CTkFrame):
    def __init__(self, parent, controller, stat):
        super().__init__(parent, border_width=2)
        self.__controller = controller
        self.__stat = stat
        self.build_widgets(stat)
    
    def build_widgets(self, stat):
        bigFont = ctk.CTkFont(size=18, weight="bold")
        
        self.__statLabel = ctk.CTkLabel(self, text=stat, font=bigFont, anchor="w", width=50)
        self.__statLabel.pack(side="left", padx=20, pady=10)
        
        self.__BaseString = ctk.StringVar()
        self.__BaseEntry = ctk.CTkEntry(self, textvariable=self.__BaseString, state="disabled", width=40, border_width=0, justify="center")
        self.__BaseEntry.pack(side="left", padx=(0,20), pady=10)
        
        ctk.CTkLabel(self, text="IV:", anchor="center").pack(side="left", padx=(20,0), pady=10)
        self.__IVstring = ctk.StringVar()
        self.__IVstring.trace("w", self.on_IV_entry_changed)
        self.__IVEntry = ctk.CTkEntry(self, textvariable=self.__IVstring, state="disabled", width=60, justify="right")
        self.__IVEntry.pack(side="left", padx=10, pady=10)
        
        ctk.CTkLabel(self, text="EV:", anchor="center").pack(side="left", padx=(20,0), pady=10)
        self.__EVstring = ctk.StringVar(value="0")
        self.__EVstring.trace("w", self.on_entry_changed)
        self.__entry = ctk.CTkEntry(self, textvariable=self.__EVstring, width=60, justify="right")
        self.__entry.pack(side="left", padx=10, pady=10)
        
        self.__slider = ctk.CTkSlider(self, from_=0, to=252, command=self.on_slider_changed)
        self.__slider.set(0)
        self.__slider.pack(side="left", padx=20, pady=10)
        
    def on_slider_changed(self, value):
        total = self.__controller.get_EV_total()
        maximum = min(508 + int(value) - total, 252)
        
        if value <= maximum:
            self.__EVstring.set(str(int(value)))
        else:
            self.__slider.set(maximum)
            self.__EVstring.set(str(maximum))
        
    def on_entry_changed(self, *args):
        try:
            value = int(self.__EVstring.get())
            total = self.__controller.get_EV_total()
            maximum = min(508 + value - total, 252)
            
            if value < 0:
                self.__EVstring.set(str(0))
                self.__slider.set(0)
            else:
                if value <= maximum or self.__ignoreTotals == True:
                    self.__EVstring.set(str(value))
                    self.__slider.set(value)
                else:
                    self.__slider.set(maximum)
                    self.__EVstring.set(str(maximum))
            
            # If user tries to input a large number manually, this will stop it
            newTotal = self.__controller.get_EV_total()
            if newTotal > 508 and self.__ignoreTotals == False:
                newMaximum = 508 - newTotal + self.get()
                self.__EVstring.set(str(newMaximum))
                self.__slider.set(newMaximum)
            
        except ValueError:
            if self.__EVstring.get() == "":
                pass
            else:
                # Input that's not a number
                self.__EVstring.set(str(0))
                self.__slider.set(0)
        
        if self.__ignoreTotals == False:
            self.update_pokemon()
    
    def on_IV_entry_changed(self, *args):
        try:
            value = int(self.__IVstring.get())
            
            if value > 31:
                self.__IVstring.set(str(31))
            elif value < 0:
                self.__IVstring.set(str(0))
            
            if self.__ignoreTotals == False:
                self.update_pokemon_IV()
            
        except ValueError:
            if self.__IVstring.get() == "":
                pass
            else:
                self.__IVstring.set(str(0))
                self.update_pokemon_IV()
    
    def get(self):
        return int(self.__slider.get())
    
    def get_stat(self):
        return self.__stat
    
    def set_pokemon(self, pokemon):
        self.__ignoreTotals = True
        
        self.__pokemon = pokemon
        EV, IV = self.__pokemon.get_stats(self.__stat)
        base = self.__pokemon.get_base(self.__stat)
        
        self.__EVstring.set(str(EV))
        self.__slider.set(EV)
        self.__IVstring.set(str(IV))
        self.__BaseString.set(str(base))
        
        self.update_color()
        
        self.__ignoreTotals = False
    
    def update_color(self):
        nature, natureInfo = self.__pokemon.get_nature()
        
        if natureInfo[0] == natureInfo[1] == self.__stat:
            self.__statLabel.configure(text_color=("black","white"))
        elif natureInfo[0] == self.__stat:
            self.__statLabel.configure(text_color="#ff6385")
        elif natureInfo[1] == self.__stat:
            self.__statLabel.configure(text_color="#6395ff")
        else:
            self.__statLabel.configure(text_color=("black","white"))
    
    def update_pokemon(self):        
        self.__pokemon.set_EV(self.get(), self.__stat)
    
    def update_pokemon_IV(self):
        self.__pokemon.set_IV(int(self.__IVstring.get()), self.__stat)
    
    def configure_state(self, state):
        self.__IVEntry.configure(state=state)

###############################################################################