from interface import App

if __name__ == "__main__":
    interface = App()
    interface.mainloop()